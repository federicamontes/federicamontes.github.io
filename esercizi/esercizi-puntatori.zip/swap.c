#include <stdio.h>

/**
 * Funzione che scambia i valori di due variabili intere sfruttando i puntatori.
 * Poiché riceve gli indirizzi di memoria, le modifiche sono permanenti.
 * Passagio per valore vs passaggio per indirizzo
 *  
 * @param x Puntatore al primo intero
 * @param y Puntatore al secondo intero
 */
void swap(int *x, int *y) {
    // 1. Salviamo temporaneamente il valore puntato da x
    int temp = *x; 

    // 2. Sovrascriviamo il valore puntato da x con quello puntato da y
    *x = *y; // Cosa succederebbe se all'interno della funzione scrivessi x = y anziché *x = *y?

    // 3. Completiamo lo scambio inserendo il vecchio valore (salvato in temp) in y
    *y = temp;     
}

int main(void) {
    int a = 5;
    int b = 10;

    printf("=== Scambio di Variabili (Swap) tramite Puntatori ===\n");
    printf("Prima dello swap: a = %d, b = %d\n", a, b);

    // Chiamata alla funzione passando gli INDIRIZZI di memoria delle variabili (&)
    swap(&a, &b);

    printf("Dopo lo swap:   a = %d, b = %d\n", a, b);

    return 0;
}
