#include <stdio.h>
#include <stdlib.h> // Libreria fondamentale per malloc() e free()

int main(void) {
    int n = 0;

    printf("=== Allocazione Dinamica di un Array con malloc ===\n");
    printf("Quanti elementi desideri memorizzare nell'array? ");
    
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Errore: inserisci un numero valido maggiore di zero.\n");
        return 1;
    }

    // ALLOCAZIONE DINAMICA NELLO HEAP
    // Chiediamo al sistema di allocare spazio per 'n' interi contigui
    int *v = (int *)malloc(n * sizeof(int));

    // CONTROLLO DI SICUREZZA
    // Verifichiamo se il sistema ha effettivamente concesso la memoria richiesta
    if (v == NULL) {
        printf("Errore critico: memoria esaurita! Allocazione fallita.\n");
        return 1;
    }

    // INIZIALIZZAZIONE TRAMITE SCANF
    // Sfruttiamo l'aritmetica dei puntatori (v + i) per inserire i dati nei singoli slot
    printf("\nInserisci i %d valori:\n", n);
    for (int i = 0; i < n; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", (v + i)); // Equivalente a &v[i]
    }

    // STAMPA DEI DATI PER VERIFICA
    printf("\nHai inserito i seguenti valori:\n[ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", *(v + i)); // Equivalente a v[i]
    }
    printf("]\n");

    // RILASCIO DELLA MEMORIA (FONDAMENTALE)
    // Restituiamo la memoria al sistema operativo per evitare Memory Leaks
    free(v); // ovviamente per programmi piccoli non fa niente, perché alla fine del main la memoria verrà liberata, ma abituatevi a fare esplicitamente le free..
    
    // Buona norma: azzeriamo il puntatore per evitare che diventi un "dangling pointer"
    v = NULL; 

    return 0;
}
