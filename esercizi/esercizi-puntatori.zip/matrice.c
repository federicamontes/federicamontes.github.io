#include <stdio.h>
#include <stdlib.h> // Per malloc() e free()

int main(void) {
    int righe, colonne;

    printf("=== Creazione di una Matrice Dinamica (int **) ===\n");
    printf("Inserisci il numero di righe: ");
    scanf("%d", &righe);
    printf("Inserisci il numero di colonne: ");
    scanf("%d", &colonne);

    if (righe <= 0 || colonne <= 0) {
        printf("Errore: le dimensioni devono essere maggiori di zero.\n");
        return 1;
    }

    // ALLOCAZIONE DELL'ARRAY PRINCIPALE DI PUNTATORI ALLE RIGHE (int **)
    // Chiediamo spazio per 'righe' puntatori a intero
    int **matrice = (int **)malloc(righe * sizeof(int *));
    if (matrice == NULL) {
        printf("Errore critico: memoria esaurita per l'array delle righe!\n");
        return 1;
    }

    // ALLOCAZIONE DELLO SPAZIO PER LE COLONNE DI CIASCUNA RIGA
    for (int i = 0; i < righe; i++) {
        matrice[i] = (int *)malloc(colonne * sizeof(int));
        
        // Controllo difensivo per allocazioni parziali
        if (matrice[i] == NULL) {
            printf("Errore critico: memoria esaurita per la riga %d!\n", i);
            
            // Pulizia di emergenza delle righe precedentemente allocate con successo
            for (int j = 0; j < i; j++) {
                free(matrice[j]);
            }
            free(matrice); // Libera l'array dei puntatori
            return 1;
        }
    }

    // RIEMPIMENTO DELLA MATRICE CON VALORI PROGRESSIVI
    int contatore = 1;
    for (int i = 0; i < righe; i++) {
        for (int j = 0; j < colonne; j++) {
            matrice[i][j] = contatore++;
        }
    }

    // STAMPA MATRICE
    printf("\nMatrice dinamica generata (%dx%d):\n", righe, colonne);
    for (int i = 0; i < righe; i++) {
        printf("[ ");
        for (int j = 0; j < colonne; j++) {
            printf("%3d ", matrice[i][j]);
        }
        printf("]\n");
    }

    // DEALLOCAZIONE A CASCATA (FONDAMENTALE PER EVITARE MEMORY LEAKS)
    // Step A: Liberiamo la memoria allocata per ciascuna riga
    for (int i = 0; i < righe; i++) {
        free(matrice[i]);
    }

    // Step B: Liberiamo l'array principale dei puntatori alle righe
    free(matrice);
    matrice = NULL; // Evitiamo dangling pointer

    printf("\nMemoria deallocata correttamente con successo.\n");

    return 0;
}
