#include <stdio.h>

#define DIM 10

/**
 * Funzione che stampa un array in ordine inverso (dall'ultimo al primo elemento)
 * utilizzando ESCLUSIVAMENTE l'aritmetica dei puntatori, senza la notazione a parentesi quadre.
 * 
 * @param v Puntatore al primo elemento dell'array
 * @param n La dimensione dell'array
 */
void stampaInverso(int *v, int n) {
    printf("[ ");
    
    // Scorriamo l'array partendo dall'indice n - 1 (ultimo elemento) fino a 0
    for (int i = n - 1; i >= 0; i--) {
        // *(v + i) dereenzia l'indirizzo ottenuto spostandosi di i posizioni rispetto a v.
        // È l'equivalente geometrico e logico di v[i], ma basato puramente sui puntatori.
        printf("%d ", *(v + i));
    }
    
    printf("]\n");
}

int main(void) {
    int arr[DIM];

    printf("=== Scansione Inversa con Aritmetica dei Puntatori ===\n");
    printf("Inserisci %d numeri interi:\n", DIM);

    // Acquisizione dei dati dall'utente usando l'aritmetica dei puntatori anche nella scanf
    // (arr + i) è perfettamente identico a &arr[i]
    for (int i = 0; i < DIM; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", (arr + i));
    }

    // Chiamata alla funzione di stampa al contrario
    printf("\nArray stampato dall'ultimo al primo:\n");
    stampaInverso(arr, DIM);

    return 0;
}
