#include <stdio.h>

int main(void) {
    // Dichiariamo una variabile float normale
    float numero;

    // Dichiariamo un puntatore a float e lo inizializziamo con l'indirizzo di 'numero'
    float *ptr = &numero;

    // Assegnazione di un valore utilizzando ESCLUSIVAMENTE il puntatore
    // L'operatore '*' ci permette di scrivere nella cella di memoria puntata
    *ptr = 25.0f; // Il suffisso 'f' specifica che è un float letterale

    // Modifica del valore aggiungendo 10.5 tramite il puntatore
    // L'espressione *ptr += 10.5f è equivalente a: *ptr = *ptr + 10.5f;
    *ptr += 10.5f;

    // Stampa del valore finale e dell'indirizzo di memoria
    printf("=== Manipolazione di Float tramite Puntatore ===\n");
    
    // Stampiamo il valore usando la dereferenziazione (*ptr)
    printf("Valore finale della variabile: %.2f\n", *ptr); 

    // Cosa succederebbe se scrivessi printf("%p", ptr); senza l'asterisco rispetto a *ptr?
    
    // Stampiamo l'indirizzo di memoria usando il puntatore (ptr) e lo specificatore %p
    // Nota: (void*) è il cast standard richiesto per la stampa sicura degli indirizzi
    printf("Indirizzo di memoria:          %p\n", (void*)ptr);

    return 0;
}
