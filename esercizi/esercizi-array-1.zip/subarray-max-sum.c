#include <stdio.h>

/**
 * Funzione che trova la somma contigua massima di un sottoarray 
 * utilizzando un algoritmo noto come Algoritmo di Kadane, che usa la tecnica della Programmazione Dinamica in tempo O(N) e spazio O(1).
 * Un approccio a forza bruta, ossia che prova le varie combinazione, richiederebbe O(N^3), la programmazione dinamica ci viene in aiuto. 
 *
 * @param v L'array di interi (può contenere anche valori negativi)
 * @param n La dimensione dell'array
 * @return La somma massima contigua trovata
 */
int maxSubarraySum(int v[], int n) {
    // Controllo difensivo: se l'array è vuoto, la somma massima è 0
    if (n == 0) {
        return 0;
    }

    // Inizializziamo entrambi i valori con il primo elemento dell'array
    int max_corrente = v[0]; // rappresenta la somma massima parziale del sotto-array esaminato fino a posizione i
    int max_globale = v[0]; // rappresenta la somma massima in assoluto incontrata fin'ora, aggiornata a partire da max_corrente se necessario

    // Scansione dell'array a partire dal secondo elemento (indice 1)
    for (int i = 1; i < n; i++) {
        // Scelta strategica (Programmazione Dinamica):
        // Decidiamo se estendere il sottoarray precedente aggiungendo v[i] 
        // oppure se conviene "abbandonare" il passato e ricominciare un nuovo sottoarray da v[i].
        if (v[i] > max_corrente + v[i]) {
            max_corrente = v[i]; // Ricominciamo un nuovo sottoarray
        } else {
            max_corrente = max_corrente + v[i]; // Estendiamo il sottoarray esistente
        }

        // Aggiorniamo il "record storico" se il massimo corrente supera il massimo globale
        if (max_corrente > max_globale) {
            max_globale = max_corrente;
        }
    }

    return max_globale;
}

int main(void) {
    int v[] = {-2, 1, -3, 4, -1, 2, 1, -5, 4};
    int n = 9;

    printf("=== Algoritmo di Kadane (Sottoarray con Somma Massima) ===\n");
    printf("Array di input: [ -2, 1, -3, 4, -1, 2, 1, -5, 4 ]\n"); // stampa statica solo per visualizzare...

    int somma_max = maxSubarraySum(v, n);

    //  Cosa succede se l'array contiene esclusivamente numeri positivi?

    printf("La somma massima contigua e': %d\n", somma_max);
    // Nota didattica: Il sottoarray con somma massima corrispondente è [4, -1, 2, 1] -> Somma = 6

    return 0;
}
