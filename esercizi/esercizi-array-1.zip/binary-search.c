#include <stdio.h>

/**
 * Funzione che esegue la Ricerca Binaria (Binary Search) su un array ordinato.
 * Sfrutta il paradigma "Divide et Impera" per dimezzare lo spazio di ricerca a ogni iterazione.
 * 
 * Complessità temporale O(logN), Complessità spaziale O(1). Se volessi scriverla in modo ricorsivo, come cambiano le complessità?
 *
 * @param v L'array di interi (DEVE essere ordinato in modo crescente)
 * @param n La dimensione dell'array
 * @param target Il valore da cercare
 * @return L'indice dell'elemento se trovato, oppure -1 se non è presente
 */
int ricercaBinaria(int v[], int n, int target) {
    int inizio = 0;
    int fine = n - 1;

    // Finché la finestra di ricerca è valida (almeno un elemento da controllare)
    while (inizio <= fine) { // Perché usiamo la condizione <= e non < nel while?
        // Calcolo sicuro del punto medio per evitare l'Arithmetic Overflow.
        // EVITARE (inizio + fine) / 2: se inizio e fine sono grandi, la somma può superare INT_MAX, causando un successivo segmentation fault in accesso all'array.
        int mezzo = inizio + (fine - inizio) / 2;

        // Caso 1: Elemento trovato al centro
        if (v[mezzo] == target) {
            return mezzo; 
        }

        // Caso 2: Il target è maggiore, cerco nella metà di destra
        if (v[mezzo] < target) {
            inizio = mezzo + 1; 
        } 
        // Caso 3: Il target è minore, cerco nella metà di sinistra
        else {
            fine = mezzo - 1;    
        }
    }

    return -1; // Elemento non trovato dopo aver esaurito la ricerca
}

int main(void) {
    // PREREQUISITO: L'array di input deve essere rigorosamente ordinato
    int v[] = {2, 5, 8, 12, 16, 23, 38, 56, 72, 91};
    int n = 10;
    int target = 23;

    printf("=== Ricerca Binaria (Binary Search) ===\n");
    printf("Array di ricerca: [ 2, 5, 8, 12, 16, 23, 38, 56, 72, 91 ]\n");
    printf("Valore cercato: %d\n", target);


    // Domanda: Cosa succede se ci sono elementi duplicati nell'array?
    int idx = ricercaBinaria(v, n, target);

    if (idx != -1) {
        printf("Risultato: Elemento %d trovato all'indice %d.\n", target, idx);
    } else {
        printf("Risultato: Elemento %d non presente nell'array.\n", target);
    }

    return 0;
}
