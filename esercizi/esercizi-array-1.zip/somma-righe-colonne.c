#include <stdio.h>

/**
 * Funzione che calcola la somma degli elementi di ciascuna riga della matrice.
 * Sfrutta la sintassi VLA (Variable Length Arrays) introdotti nello standard C99.
 * 
 * @param r Numero di righe
 * @param c Numero di colonne
 * @param mat La matrice bidimensionale (passata con le dimensioni dinamiche)
 * @param res Array di output in cui memorizzare le somme delle righe (dimensione r)
 */

// Domanda 1: Perché se inverto l'ordine dei parametri inserendo mat prima di r e c la funzione non compila?
void sommaRighe(int r, int c, int mat[r][c], int res[]) {
    for (int i = 0; i < r; i++) {
        res[i] = 0; // Azzeramento dell'accumulatore per la riga corrente
        // perché l'azzeramento di res[i] si trova qui? (Analogo in sommaColonne)
        
	for (int j = 0; j < c; j++) {
            res[i] += mat[i][j]; // Accumula gli elementi della riga i
        }
    }
}

/**
 * Funzione che calcola la somma degli elementi di ciascuna colonna della matrice.
 * 
 * @param r Numero di righe
 * @param c Numero di colonne
 * @param mat La matrice bidimensionale
 * @param res Array di output in cui memorizzare le somme delle colonne (dimensione c)
 */
void sommaColonne(int r, int c, int mat[r][c], int res[]) {
    for (int j = 0; j < c; j++) {
        res[j] = 0; // Azzeramento dell'accumulatore per la colonna corrente
        
        for (int i = 0; i < r; i++) {
            res[j] += mat[i][j]; // Accumula gli elementi della colonna j
        }
    }
}

int main(void) {
    int R = 3, C = 3;
    int M[3][3] = {
        {1, 2, 3},
        {4, 5, 6},
        {7, 8, 9}
    };

    int s_righe[3];
    int s_colonne[3];

    // Chiamata delle funzioni di calcolo
    sommaRighe(R, C, M, s_righe);
    sommaColonne(R, C, M, s_colonne);

    // Stampa dei risultati per riga
    printf("=== Somma di Righe e Colonne in una Matrice ===\n");
    printf("Somma per riga:    ");
    for (int i = 0; i < R; i++) {
        printf("%d ", s_righe[i]);
    }

    // Stampa dei risultati per colonna
    printf("\nSomma per colonna: ");
    for (int j = 0; j < C; j++) {
        printf("%d ", s_colonne[j]);
    }
    printf("\n");

   // Domanda 2: Possiamo calcolare sia le somme delle righe che quelle delle colonne in un UNICO doppio ciclo for?

    return 0;
}
