#include <stdio.h>

/**
 * Funzione che rimuove i duplicati da un array ordinato direttamente in-place.
 * Sfrutta la tecnica dei "Due Indici" (Two Pointers) per operare con spazio ausiliario O(1).
 * 
 * @param v L'array di interi (DEVE essere ordinato in modo crescente)
 * @param n La dimensione iniziale dell'array
 * @return La nuova dimensione logica K dell'array contenente solo valori distinti
 */
int rimuoviDuplicati(int v[], int n) {
    // Controllo difensivo: se l'array è vuoto, la nuova dimensione è 0
    if (n == 0) {
        return 0;
    }

    // L'indice 'scrittura' tiene traccia di dove posizionare il prossimo elemento unico.
    // Partiamo da 1 perché il primo elemento (indice 0) è per definizione unico.
    int scrittura = 1;

    // L'indice 'lettura' scorre l'array alla ricerca di nuovi elementi distinti
    for (int lettura = 1; lettura < n; lettura++) {
        // Poiché l'array è ordinato, i duplicati si trovano necessariamente in posizioni adiacenti!
        // Se l'elemento corrente è diverso dal precedente, abbiamo trovato un nuovo valore unico!
        if (v[lettura] != v[lettura - 1]) {
            v[scrittura] = v[lettura]; // Sovrascriviamo in-place nella posizione di scrittura
            scrittura++;               // Avanziamo il puntatore di scrittura
        }
    }

    // 'scrittura' corrisponde esattamente al numero di elementi unici trovati (dimensione logica K)
    return scrittura; 
}

int main(void) {
    // PREREQUISITO: L'array di input deve essere rigorosamente ordinato
    int v[] = {1, 1, 2, 2, 2, 3, 4, 4, 5};
    int n = 9;

    printf("=== Rimozione Duplicati In-Place ===\n");
    printf("Array originale: [ 1, 1, 2, 2, 2, 3, 4, 4, 5 ]\n");

    int k = rimuoviDuplicati(v, n);

    // Stampa del risultato utilizzando la nuova dimensione logica K
    printf("Nuova lunghezza (K): %d\n", k);
    printf("Array ridotto:     [ ");
    for (int i = 0; i < k; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");

    return 0;
}
