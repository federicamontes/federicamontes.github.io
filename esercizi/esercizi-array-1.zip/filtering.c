#include <stdio.h>

/**
 * Funzione che estrae tutti i numeri pari da un array sorgente e li copia in un array di destinazione.
 * 
 * @param sorgente L'array di input da cui leggere i dati
 * @param n_sorgente La dimensione dell'array sorgente
 * @param destinazione L'array di output che conterrà solo i numeri pari
 * @return Il numero effettivo di elementi pari trovati e copiati (dimensione logica)
 */
int estraiPari(int sorgente[], int n_sorgente, int destinazione[]) {
    int k = 0; // Indice logico di scrittura per l'array destinazione

    // uso due indici per scorrere l'array sorgente e quello destinazione (i e k rispettivamente), perché è fondamentale?

    // Scansione sequenziale dell'array sorgente
    for (int i = 0; i < n_sorgente; i++) {
        // Verifica se l'elemento corrente è pari
        if (sorgente[i] % 2 == 0) {
            destinazione[k] = sorgente[i]; // Scriviamo nella prossima cella disponibile
            k++;                          // Avanziamo l'indice di destinazione
        }
    }

    // Restituisce quanti elementi validi sono stati inseriti
    return k; 
}

int main(void) {
    int dati[8] = {15, 4, 23, 8, 12, 11, 16, 7};
    int pari[8]; // Array di destinazione (capienza massima pari al sorgente)

    // Estrazione dei numeri pari e salvataggio del numero effettivo di elementi trovati
    int n_pari = estraiPari(dati, 8, pari);

    // Stampa dei risultati usando rigorosamente n_pari (dimensione logica)
    printf("=== Filtraggio Numeri Pari ===\n");
    printf("Elementi pari trovati (%d): [ ", n_pari);
    for (int i = 0; i < n_pari; i++) {
        printf("%d ", pari[i]);
    }
    printf("]\n");

    return 0;
}
