#include <stdio.h>

/**
 * Funzione che trova la somma massima tra tutti i sottoarray contigui di lunghezza esattamente k
 * utilizzando una tecnica nota come Finestra Scorrevole (Sliding Window) in tempo O(N).
 * Un algoritmo a forza bruta impiega O(KN) con k dimensione del sotto array
 * Sliding Window: uando la "finestra" si sposta a destra di un passo, gli elementi interni rimangono gli stessi tranne due: uno esce a sinistra e uno entra a destra. 
 * Aggiornare la somma costa appena O(1) operazioni algebriche. È molto utile per calcolare la media mobile (moving average value).
 *
 * @param v L'array di interi
 * @param n La dimensione dell'array
 * @param k La dimensione fissa della finestra
 * @return La somma massima trovata, oppure -1 se k è maggiore di n
 */
int maxSommaFinestra(int v[], int n, int k) {
    // Controllo difensivo: se la finestra è più grande dell'array, non è possibile calcolarla
    if (n < k || k <= 0) {
        return -1;
    }

    // Che succede se k = 1?

    // 1. Calcolo preliminare della somma della prima finestra (i primi k elementi)
    int somma_finestra = 0;
    for (int i = 0; i < k; i++) {
        somma_finestra += v[i];
    }

    int somma_massima = somma_finestra;

    // 2. Sliding Window: facciamo scorrere la finestra di una posizione verso destra ad ogni iterazione.
    // Invece di ricalcolare la somma da capo, sottraiamo l'elemento che esce a sinistra (v[i - k]) 
    // e aggiungiamo il nuovo elemento che entra a destra (v[i]).
    for (int i = k; i < n; i++) {
        somma_finestra += v[i] - v[i - k]; // Aggiornamento in tempo O(1)

        // Aggiorniamo il record della somma massima se superiamo il valore precedente
        if (somma_finestra > somma_massima) {
            somma_massima = somma_finestra;
        }
    }

    return somma_massima;
}

int main(void) {
    int v[] = {2, 1, 5, 1, 3, 2};
    int n = 6;
    int k = 3;

    printf("=== Finestra Scorrevole (Sliding Window) ===\n");
    printf("Array di input: [ 2, 1, 5, 1, 3, 2 ], Dimensione finestra (k): %d\n", k); // stampa statica solo per visualizzare, cambiare se si cambia input o usare funzione ausiliaria

    int risultato = maxSommaFinestra(v, n, k);

    printf("La somma massima della finestra di dimensione %d e': %d\n", k, risultato);
    // Nota didattica: La finestra con somma massima corrispondente è [5, 1, 3] -> Somma = 9

    return 0;
}
