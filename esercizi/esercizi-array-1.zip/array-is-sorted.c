#include <stdio.h>

/**
 * Funzione che verifica se un array è ordinato in modo crescente.
 * Complessità best-case: O(1)
 * Complessità worst-case: O(N)
 * 
 * @param v L'array di interi da controllare
 * @param n La dimensione dell'array
 * @return 1 se l'array è ordinato, 0 altrimenti
 */
int esOrdinato(int v[], int n) {
    // Scorriamo fino a n - 1 per evitare di sforare i limiti con v[i + 1]
    for (int i = 0; i < n - 1; i++) {
        // Se troviamo un elemento maggiore del suo successivo, l'ordine crescente è violato
        if (v[i] > v[i + 1]) {
            return 0; // Uscita anticipata (Early Exit): l'array NON è ordinato
        }
    }
    
    return 1; // Se il ciclo termina senza violazioni, l'array è ordinato
}

int main(void) {
    int a1[5] = {10, 20, 30, 40, 50};
    int a2[5] = {10, 30, 20, 40, 50};

    // Domanda 1: Cosa succede se passiamo alla funzione un array di dimensione n = 0 o n = 1?
    // Domanda 2: Che succede se passiamo alla funzione array con elementi duplicati?

    printf("=== Verifica Array Ordinato ===\n");
    printf("Array 1: {10, 20, 30, 40, 50}\n");
    printf("Array 1 ordinato? %s\n\n", esOrdinato(a1, 5) ? "SI" : "NO");

    printf("Array 2: {10, 30, 20, 40, 50}\n");
    printf("Array 2 ordinato? %s\n", esOrdinato(a2, 5) ? "SI" : "NO");

    return 0;
}
