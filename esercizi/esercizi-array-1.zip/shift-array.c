#include <stdio.h>

/**
 * Funzione per stampare un array formattato.
 */
void stampaArray(int v[], int n) {
    printf("[ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");
}

/**
 * Funzione che sposta (shift) tutti gli elementi dell'array a destra di una posizione.
 * L'ultimo elemento della coda viene fatto "rimbalzare" in testa (rotazione circolare).
 * 
 * Se volessi ruotare l'array di K posizioni invece di 1 sola, come cambierebbe l'algoritmo?
 *
 * @param v L'array di interi da ruotare (modificato in-place)
 * @param n La dimensione dell'array
 */
void ruotaDestra(int v[], int n) {
    // Controllo difensivo: se l'array è vuoto o ha un solo elemento, non c'è nulla da ruotare
    if (n <= 1) { // clausola di guardia (guard clause) per impedire accessi non validi	
        return;
    }

    // 1. Salvataggio temporaneo dell'ultimo elemento, altrimenti andrebbe perduto
    int ultimo = v[n - 1]; 

    // 2. Traslazione a destra: scorriamo dal fondo verso l'inizio (da n-1 fino a 1)
    // ATTENZIONE: È fondamentale procedere da destra a sinistra per evitare sovrascritture!
    for (int i = n - 1; i > 0; i--) {
        v[i] = v[i - 1];
    }

    // 3. Inserimento dell'ultimo elemento salvato nella prima posizione (indice 0)
    v[0] = ultimo; 
}

int main(void) {
    int arr[5] = {1, 2, 3, 4, 5};

    printf("=== Shift Circolare a Destra ===\n");
    printf("Originale:                 ");
    stampaArray(arr, 5);

    // Esecuzione della rotazione (modifica l'array direttamente in-place)
    ruotaDestra(arr, 5);

    printf("Dopo la rotazione a destra: ");
    stampaArray(arr, 5);

    return 0;
}
