#include <stdio.h>

/**
 * Funzione che conta quante volte un determinato valore compare in un array.
 * Complessità: O(N), si può fare di meglio? Sì, ma solo se l'array rispetta una certa condizione..Quale?
 * 
 * @param v L'array di interi (ricevuto come puntatore al primo elemento)
 * @param n La dimensione dell'array
 * @param valore Il numero da cercare
 * @return Il numero di occorrenze trovate
 */
// perché passo anche int n alla funzione?
// Domanda 1: Perché nella firma scriviamo int v[] senza specificare la dimensione (es. int v[10])?
int contaOccorrenze(int v[], int n, int valore) { // come può cambiare questa firma? 
    int conteggio = 0;

    // Domanda 2: Cosa succede se modifico un valore di v[i] dentro la funzione contaOccorrenze? Si modifica anche nel main?

    // Scansione sequenziale dell'intero array (Linear Search)
    for (int i = 0; i < n; i++) {
        if (v[i] == valore) {
            conteggio++;
        }
    }

    return conteggio;
}

int main(void) {
    // Definizione e inizializzazione di un array di 10 elementi
    int numeri[10] = {4, 2, 7, 4, 9, 4, 1, 8, 2, 4};
    int bersaglio;

    printf("=== Conteggio Occorrenze in un Array ===\n");
    printf("Inserisci il numero da cercare: ");
    scanf("%d", &bersaglio);

    // Chiamata alla funzione passando l'array, la sua dimensione e il valore target
   // Attenzione al passaggio dell'array ad una funzione, cosa succede all'array? 
   int trovati = contaOccorrenze(numeri, 10, bersaglio);
    
    printf("Il numero %d compare %d volte nell'array.\n", bersaglio, trovati);

    return 0;
}
