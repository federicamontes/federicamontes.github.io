#include <stdio.h>

/**
 * Funzione che conta quanti elementi distinti compaiono esattamente due volte nell'array.
 * Complessità temporale O(N^2)
 * @param arr L'array di interi da analizzare
 * @param size La dimensione dell'array
 * @return Il numero di elementi che appaiono esattamente 2 volte
 */
int conta_elementi_doppi(int arr[], int size) {
    int coppie_trovate = 0;

    // Ciclo esterno: analizza ogni elemento dell'array uno alla volta
    for (int i = 0; i < size; i++) {
        int conteggio = 0;

        // 1. Primo ciclo interno: conta quante volte arr[i] appare nell'intero array
        for (int j = 0; j < size; j++) {
            if (arr[j] == arr[i]) {
                conteggio++;
            }
        }

        // 2. Se l'elemento appare esattamente 2 volte, dobbiamo evitare 
        // di contarlo più volte quando incontriamo la sua seconda apparizione.
        if (conteggio == 2) {
            int appeared = 0;

            // Secondo ciclo interno: guarda all'indietro (a sinistra dell'indice i)
            // per verificare se abbiamo già processato questo stesso numero in precedenza.
            for (int k = 0; k < i; k++) {
                if (arr[k] == arr[i]) {
                    appeared = 1; // Trovato! Significa che non è la prima volta che lo incontriamo
                    break;
                }
            }

            // Se è la prima volta che incontriamo questa coppia, incrementiamo il contatore
            if (!appeared) {
                coppie_trovate++;
            }
        }
    }

    return coppie_trovate;
}

int main(void) {
    int arr[] = {4, 5, 6, 4, 7, 5, 8}; // Esempio: 4 e 5 compaiono 2 volte ciascuno
    int size = 7;

    printf("=== Conteggio Elementi con Frequenza Esattamente 2 ===\n");
    printf("Elementi che compaiono esattamente 2 volte: %d\n", conta_elementi_doppi(arr, size));

    return 0;
}
