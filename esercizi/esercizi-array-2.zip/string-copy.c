#include <stdio.h>

/**
Il ciclo while si interrompe prima di copiare il carattere \0 (perché la condizione di guardia è sorgente[i] != '\0')
Ricordarsi di aggiungere il carattere di terminazione stringa '\0'
*/

int main(void) {
    // Definizione della stringa sorgente e dell'array di destinazione con dimensione fissa
    char sorgente[] = "Ingegneria Degli Algoritmi";
    char destinazione[50]; // L'array di destinazione deve essere abbastanza grande
    int i = 0;

    // Copia carattere per carattere dalla sorgente alla destinazione
    while (sorgente[i] != '\0') {
        destinazione[i] = sorgente[i];
        i++;
    }
    
    // FONDAMENTALE: Aggiunta manuale del terminatore di stringa '\0' alla fine.
    // Il ciclo while si è fermato prima di copiarlo, quindi dobbiamo inserirlo esplicitamente.
    destinazione[i] = '\0'; 

    // Stampa dei risultati
    printf("=== Copia di una Stringa ===\n");
    printf("Stringa sorgente: %s\n", sorgente);
    printf("Stringa copiata:  %s\n", destinazione);

    return 0;
}
