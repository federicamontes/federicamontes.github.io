#include <stdio.h>

int main(void) {
    // Definizione di una stringa (array di caratteri)
    // Il C aggiunge automaticamente il terminatore '\0' alla fine ("Programmazione\0")
    char str[] = "Ingegneria degli Algoritmi";
    int lunghezza = 0;

    // Scorre la stringa carattere per carattere 
    // finché non incontra il carattere terminatore '\0' (byte nullo)
    while (str[lunghezza] != '\0') {
        lunghezza++;
    }

    // Stampa del risultato
    printf("=== Calcolo Lunghezza Stringa Senza strlen ===\n");
    printf("La stringa analizzata e': \"%s\"\n", str);
    printf("La lunghezza della stringa e': %d\n", lunghezza);

    return 0;
}
