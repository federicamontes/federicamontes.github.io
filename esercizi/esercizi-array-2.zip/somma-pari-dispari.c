#include <stdio.h>

// Definizione di una costante per la dimensione dell'array
#define DIM 10

int main(void) {
    // Dichiarazione dell'array di interi
    int arr[DIM];
    
    // Uso di long long per prevenire l'overflow in caso di somme di numeri grandi
    long long somma_pari = 0;
    long long somma_dispari = 0;

    printf("=== Calcolo Somma Pari e Dispari ===\n");
    printf("Inserisci %d numeri interi:\n", DIM);

    // Ciclo di lettura e smistamento dei dati nell'array
    for (int i = 0; i < DIM; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", &arr[i]);

        // Verifica della parità usando l'operatore modulo (%)
        if (arr[i] % 2 == 0) {
            somma_pari += arr[i];     // Accumula se il numero è pari
        } else {
            somma_dispari += arr[i];  // Accumula se il numero è dispari
        }
    }

    // Stampa dei risultati finali
    printf("\n--- Risultati ---\n");
    printf("Somma dei numeri pari: %lld\n", somma_pari);
    printf("Somma dei numeri dispari: %lld\n", somma_dispari);

    return 0;
}
