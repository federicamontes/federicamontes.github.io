#include <stdio.h>
#include <limits.h> // Necessario per usare INT_MIN

/**
Complessità Temporale O(N): in una unica scansione dell'array si risolve il problema.
Gestione dei Duplicati (arr[i] != primo) nell'else if
*/


// Costante per la dimensione dell'array
#define DIM 10

int main(void) {
    int arr[DIM];

    // 1. Acquisizione dei valori da tastiera
    printf("=== Ricerca del Secondo Numero Piu' Grande ===\n");
    printf("Inserisci %d numeri interi:\n", DIM);
    for (int i = 0; i < DIM; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    // Inizializzazione delle variabili al valore minimo possibile per gli interi
    int primo = INT_MIN;
    int secondo = INT_MIN;

    // 2. Scansione lineare dell'array in un unico passaggio (O(N))
    for (int i = 0; i < DIM; i++) {
        if (arr[i] > primo) {
            // Se troviamo un numero maggiore del massimo attuale:
            // Il vecchio massimo scala a "secondo massimo"
            secondo = primo;
            // Il nuovo numero diventa il massimo assoluto
            primo = arr[i];
        } 
        else if (arr[i] > secondo && arr[i] != primo) {
            // Se il numero è compreso tra 'secondo' e 'primo' 
            // (e non è un duplicato del primo), aggiorniamo 'secondo'
            secondo = arr[i];
        }
    }

    // 3. Controllo ed emissione del risultato
    if (secondo == INT_MIN) {
        printf("\nNon esiste un secondo numero piu' grande distinto (es. tutti i numeri sono uguali).\n");
    } else {
        printf("\nIl numero massimo e': %d\n", primo);
        printf("Il secondo numero piu' grande e': %d\n", secondo);
    }

    return 0;
}
