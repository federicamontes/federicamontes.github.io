#include <stdio.h>

/**
 * Funzione che unisce due array in un unico vettore e li ordina in ordine decrescente.
 * Complessità della fase di fusione: O(N1 + N2) 
 * @param arr1 Primo array di input
 * @param size1 Dimensione del primo array
 * @param arr2 Secondo array di input
 * @param size2 Dimensione del secondo array
 * @param risultato Array di output che conterrà i dati fusi e ordinati (deve essere abbastanza grande)
 */
void fondi_e_ordina_decrescente(int arr1[], int size1, int arr2[], int size2, int risultato[]) {
    int dim_totale = size1 + size2;

    // 1. Copia degli elementi del primo array nel vettore risultato
    for (int i = 0; i < size1; i++) {
        risultato[i] = arr1[i];
    }
    
    // 2. Copia degli elementi del secondo array in coda al primo
    for (int i = 0; i < size2; i++) {
        risultato[size1 + i] = arr2[i];
    }

    // 3. Ordinamento dell'array unito in ordine decrescente (Bubble Sort modificato)
    for (int i = 0; i < dim_totale - 1; i++) {
        for (int j = 0; j < dim_totale - i - 1; j++) {
            // Condizione invertita (< anziché >): sposta i valori minori verso la fine
            // ottenendo così un ordinamento decrescente (dal più grande al più piccolo)
            if (risultato[j] < risultato[j + 1]) {
                int temp = risultato[j];
                risultato[j] = risultato[j + 1];
                risultato[j + 1] = temp;
            }
        }
    }
}

int main(void) {
    int a1[] = {1, 3, 5};
    int a2[] = {2, 4, 6};
    int dim1 = 3;
    int dim2 = 3;
    
    // L'array risultato deve avere una dimensione pari alla somma delle due dimensioni
    int risultato[6];

    // Chiamata alla funzione di fusione e ordinamento
    fondi_e_ordina_decrescente(a1, dim1, a2, dim2, risultato);

    // Stampa del risultato finale
    printf("=== Unione e Ordinamento Decrescente ===\n");
    printf("Array unito e decrescente: ");
    for (int i = 0; i < (dim1 + dim2); i++) {
        printf("%d ", risultato[i]);
    }
    printf("\n");

    return 0;
}
