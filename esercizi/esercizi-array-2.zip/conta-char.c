#include <stdio.h>

int main(void) {
    // Definizione della stringa e del carattere da cercare
    char str[] = "programmare in c";
    char target = 'r';
    int conteggio = 0;

    // Scansione della stringa carattere per carattere fino al terminatore '\0'
    for (int i = 0; str[i] != '\0'; i++) {
        // Se il carattere corrente corrisponde al target, incrementiamo il contatore
        if (str[i] == target) {
            conteggio++;
        }
    }

    // Stampa del risultato formattato
    printf("=== Conteggio Occorrenze Carattere ===\n");
    printf("Stringa analizzata: \"%s\"\n", str);
    printf("Il carattere '%c' compare %d volte.\n", target, conteggio);

    return 0;
}
