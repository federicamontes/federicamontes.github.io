#include <stdio.h>


/** UNA possibile soluzione dell'esercizio
Il codice proposto implementa l'algoritmo Bubble Sort standard.
Analisi della Complessità Algoritmica:
- Complessità Temporale:
Caso Peggiore (O(N^2)): Array ordinato in senso decrescente. Effettua N(N-1)/2 confronti e scambi. 
Caso Medio (O(N^2)): Elementi in ordine casuale. 
Caso Migliore (O(N^2) nella versione fornita): Anche se l'array è già ordinato, questo codice esegue comunque tutti i confronti. 
(Nota: introducendo un flag 'swapped' l'algoritmo potrebbe scendere a O(N) nel caso migliore).

- Complessità Spaziale (O(1)): Algoritmo in-place; utilizza solo una quantità costante di memoria ausiliaria (temp, i, j).


*/

// Costante per la dimensione dell'array
#define DIM 10

int main(void) {
    int arr[DIM];

    // 1. Acquisizione degli elementi da tastiera
    printf("=== Ordinamento Array (Bubble Sort) ===\n");
    printf("Inserisci %d numeri interi:\n", DIM);
    for (int i = 0; i < DIM; i++) {
        printf("Elemento %d: ", i + 1);
        scanf("%d", &arr[i]);
    }

    // 2. Algoritmo di ordinamento: Bubble Sort
    // Il ciclo esterno riduce ad ogni passo la porzione di array da analizzare
    for (int i = 0; i < DIM - 1; i++) {
        // Il ciclo interno confronta elementi adiacenti fino all'ultimo elemento non ancora posizionato
        for (int j = 0; j < DIM - i - 1; j++) {
            // Confronto per ordinamento crescente
            if (arr[j] > arr[j + 1]) {
                // Scambio (swap) dei due elementi tramite variabile temporanea
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }

    // 3. Stampa dell'array ordinato
    printf("\nArray ordinato in ordine crescente:\n");
    for (int i = 0; i < DIM; i++) {
        printf("%d ", arr[i]);
    }
    printf("\n");

    return 0;
}
