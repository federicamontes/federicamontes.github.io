#include <stdio.h>

int main(void) {
    char buffer[5] = "Ciao!"; // 4 caratteri + '\0'
    int segreto = 42;         // Variabile intera allocata subito dopo nello Stack

    printf("Prima del traboccamento: segreto = %d\n", segreto);

    // ERRORE: Scrittura manuale oltre i limiti dell'array (indici validi: 0-4)
    // Stiamo scrivendo direttamente nella memoria occupata dalla variabile 'segreto'
    for (int i = 0; i < 10; i++) {
        buffer[i] = 'A'; // 'A' in ASCII è 65
    }

    printf("Dopo il traboccamento: segreto = %d (valore corrotto!)\n", segreto);

    return 0;
}
