#include <stdio.h>
#include <string.h>

void funzione_vulnerabile(char *input_utente) {
    char buffer[5]; // Spazio allocato per soli 5 caratteri (inclusi '\0')

    printf("Indirizzo del buffer: %p\n", (void*)buffer);

    // PERICOLO: strcpy non controlla la lunghezza di input_utente!
    // Se la stringa è più lunga di 4 caratteri (+ '\0'), scrive oltre i limiti.
    strcpy(buffer, input_utente);

    printf("Hai scritto nel buffer: %s\n", buffer);
}

int main(int argc, char *argv[]) {
    if (argc > 1) {
        funzione_vulnerabile(argv[1]);
    } else {
        printf("Uso: %s <stringa_da_passare>\n", argv[0]);
    }
    return 0;
}
