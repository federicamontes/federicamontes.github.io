#include <stdio.h>
#include <stdlib.h> // Per EXIT_SUCCESS ed EXIT_FAILURE
#include <math.h>   // Per le funzioni matematiche come sqrt()
#include <errno.h>  // Per la variabile globale errno e la costante EDOM

/**
Molte funzioni della libreria standard (come quelle matematiche) segnalano un valore errato di un'operazione impostando la variabile globale `errno`.
`errno` è semplicemente un numero intero che identifica il tipo di errore avvenuto.
Se si verifica un errore, il `main` può terminare restituendo un valore diverso da 0 (ad esempio 1 o la costante `EXIT_FAILURE`), 
per segnalare al sistema operativo che il programma è fallito.
Es. se tentiamo di effettuare una divisione per zero, il programma crasha e segnalerà la divisione per zero, internamente viene impostato errno
per comunicare al sistema operativo la natura dell'errore.
*/

/* COME COMPILARE QUESTO CODICE
Se voi compilate facendo gcc gestione-errori.c -o programma ottenete un errore, la libreria math.h va linkata esplicitamente!

gcc gestione-errori.c -lm -o gestione-errori

-lm: Dice al linker (ld) di includere la libreria matematica (-l sta per library e m sta per math). Nota importante: l'opzione -lm va messa dopo il nome del file sorgente

Perché tutte le altre funzioni viste fin'ora non ne avevano bisogno? (stdio.h, stdlib.h, string.h ..)
Perché tutte le funzioni di base appartengono alla libc che viene linkata automaticamente dal gcc!
Storicametne la libreria matematica math.h era separata per ragioni di limiti di spazio disponibile, ed è rimasta separata anche se ormai ci sarebbe spazio per memorizzare tutto..


*/

int main(void) {
    double numero = -9.0;
    
    printf("Tentativo di calcolare la radice quadrata di %.1f...\n", numero);

    // Azzeriamo errno prima dell'operazione per essere sicuri di leggere un nuovo errore
    errno = 0;

    // Tentiamo di calcolare la radice quadrata di un numero negativo
    double risultato = sqrt(numero);

    // Verifichiamo se 'errno' e' stato modificato durante il calcolo
    // Se errno e' diverso da 0, si e' verificato un errore
    if (errno != 0) {
        printf("[ERRORE RILEVATO]\n");
        printf("Codice numerico di errno: %d\n", errno);

        // perror() legge errno e stampa la spiegazione del problema
        /*
	Dal man: void perror(const char *s);
	The perror() function produces a message on standard error describing the last error encountered during a call to a system or library function.
	*/
	perror("Dettaglio dell'errore con perror"); // notate che stiamo semplicemente passando una stringa senza indicazioni sulle variabili né \n, la formattazione è automatica
	//`perror` invia il testo sullo Standard Error (`stderr`) invece dello Standard Output (`stdout`)

        // Finiamo il programma segnalando l'errore al sistema operativo
        return EXIT_FAILURE; // Restituisce un codice diverso da 0 (es. 1)
    }

    // Se non ci sono stati errori, stampiamo il risultato
    printf("Il risultato e': %.2f\n", risultato);

    return EXIT_SUCCESS; // Equivale a return 0 (Successo)
}
