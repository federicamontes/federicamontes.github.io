#include <stdio.h>
#include <string.h> 

#define DIM 10 // Dimensione del buffer piccola per evidenziare i comportamenti

/*
Input da provare:
1. Marco, Federica, Luca
2. FedericaMontesano12345, Federica, Luca
3. Marco, Massimiliano, Luca
*/


int main(void) {
    char buffer[DIM];

    // =========================================================================
    // Perché scanf("%s") è PERICOLOSA vs la sicurezza di fgets()
    // =========================================================================
    printf("--- scanf(\"%%s\") e confronto con fgets ---\n");
    printf("Inserisci un nome lungo senza spazi (es. FedericaMontesano12345): ");
    
    /* 
     * PERICOLO: %s legge fino al primo spazio/invio SENZA LIMITE DI LUNGHEZZA.
     * Se l'input supera 9 caratteri, sovrascrive lo stack (BUFFER OVERFLOW).
	Dal man di scanf:
	The  scanf() family of functions scans formatted input like sscanf(3), but read from a FILE.  It is very difficult to use these functions correctly, and it is preferable to
       read entire lines with fgets(3) or getline(3) and parse them later with sscanf(3) or more specialized functions such as strtol(3).

       The scanf() function reads input from the standard input stream stdin and fscanf() reads input from the stream pointer stream.

	CAVEATS
       These functions make it difficult to distinguish newlines from other white space, This is especially problematic with line-buffered input, like the standard input stream.

       These functions can't report errors after the last non-suppressed conversion specification.

	BUGS
       It  is  impossible  to accurately know how many characters these functions have consumed from the input stream, since they only report the number of successful conversions.
       For example, if the input is "123\n a", scanf("%d %d", &a, &b) will consume the digits, the newline, and the space, but not the letter a.  This makes it  difficult  to  re‐
       cover from invalid input.
     *
     *
     * fgets(buffer, DIM, stdin) risolve questo problema perché legge al massimo
     * DIM - 1 caratteri (9), riservando il 10° posto per il terminatore '\0'.
     */
    scanf("%s", buffer); // <-- DA NON USARE PER INPUT NON CONTROLLATI
    printf("Hai inserito con scanf: %s\n\n", buffer);
 
    // Pulizia del buffer per preparare l'esempio successivo
    // questa funzione "pulisce" eventuali caratteri rimasti dentro lo stdin (proprio perché scanf si fermerebbe al primo spazio bianco..)
    while (getchar() != '\n'); 


    // =========================================================================
    // PUNTO 2: Limite N-1 di fgets, gestione del \n e residui in stdin
    // =========================================================================
    printf("--- fgets legge max N-1 char e lascia residui se troppo lungo ---\n");
    printf("Inserisci una parola piu' lunga di 9 caratteri (es. Federica Montesano): ");
    
    /*
     * Se digiti "Federica Montesano" + Invio (12 caratteri totali):
     * 1. fgets legge solo "Federica " (9 char) DA NOTARE LO SPAZIO e aggiunge '\0' in buffer[9].
     * 2. I caratteri restanti e l'Invio ('\n') NON vengono letti da fgets.
     * 3. I caratteri rimasti rimangono bloccati nel buffer di input (stdin).
     */
    fgets(buffer, sizeof(buffer), stdin);
    printf("Stringa letta in buffer: \"%s\"\n", buffer);

    /*
     * COME PULIRE CORRETTAMENTE STDIN SE L'INPUT ERA TROPPO LUNGO:
     * Verifichiamo se il '\n' è presente nella stringa.
     * - Se c'è '\n', significa che l'input e' stato letto TUTTO e stdin e' pulito.
     * - Se NON c'e' '\n', l'input era piu' lungo di 9 char e stdin ha ancora caratteri spuri!
     */
    if (strchr(buffer, '\n') == NULL) {
        printf("-> ATTENZIONE: Input troppo lungo! Pulizia dei caratteri in eccesso da stdin...\n");
        int c;
        while ((c = getchar()) != '\n' && c != EOF); // Consuma i caratteri rimanenti
    }


    // =========================================================================
    // PUNTO 3: Gestione e rimozione del Newline '\n' letto da fgets
    // =========================================================================
    printf("\n--- PUNTO 3: Rimozione del '\\n' salvato da fgets ---\n");
    printf("Inserisci un nome breve (es. Luca): ");
    
    /*
     * Se digiti "Luca" + Invio:
     * fgets legge 'L', 'u', 'c', 'a', '\n' e poi aggiunge '\0'.
     * Il '\n' rimane nella stringa e manda a capo le stampe successive!
     */
    fgets(buffer, sizeof(buffer), stdin);
    printf("Prima della pulizia: \"Hello %s!\" (nota il newline indesiderato)\n", buffer);

    // MODO 1: Uso di strcspn (Sostituisce il primo '\n' trovato con '\0')
    /*
	Dal man: size_t strcspn(const char *s, const char *reject);
	The strcspn() function calculates the length of the initial segment of s which consists entirely of bytes not in reject. size_t strcspn(const char *s, const char *reject);
	The strcspn() function returns the number of bytes in the initial segment of s which are not in the string reject.

    */
    buffer[strcspn(buffer, "\n")] = '\0';

    /* 
     * MODO 2 (Alternativo con ciclo for):
     * for (int i = 0; buffer[i] != '\0'; i++) {
     *     if (buffer[i] == '\n') {
     *         buffer[i] = '\0';
     *         break;
     *     }
     * }
     */

    printf("Dopo la pulizia:    \"Hello %s!\"\n", buffer);

    // Che stampa vedete? 
    /*
	Se a volte vedete qualcosa del genere: 
	*** stack smashing detected ***: terminated
	Aborted (core dumped)
	È perché i compilatori moderni sanno che scanf è una funziona poco sicura per le letture di stringhe, e quindi adottano misure di sicurezza (stack canary, 
	per chi fosse interessat), per poter fare un doppio check alla fine della lettura con scanf e verificare che lo stack non sia stato sporcato.
	Perché l'errore viene reso palese solo alla fine? Perché prima di fare return 0; il programma verificherà che lo stack sia rimasto pulito.

    */

    return 0;
}
