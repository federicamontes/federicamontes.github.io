#include <stdio.h>
#include <stdlib.h> // Per la funzione atoi

/*
Provate questi input dopo aver compilato:
./program 10 20
./program 
*/

int main(int argc, char *argv[]) {
    // Verifichiamo che l'utente abbia passato esattamente 2 argomenti (+ il nome del programma)
    if (argc != 3) {
        printf("Errore: Numero di parametri non corretto!\n");
        printf("Uso corretto: %s <int> <int>\n", argv[0]);
        return 1; // Restituisce un codice di errore al sistema operativo
    }

    // Convertiamo le stringhe argv[1] e argv[2] in interi
    /*
	Dal man: int atoi(const char *nptr);
	The atoi() function converts the initial portion of the string pointed to by nptr to int.  The behavior is the same as

           strtol(nptr, NULL, 10);

       except that atoi() does not detect errors.

	BUGS:
	No checks for overflow or underflow are done.  Only base-10
       input can be converted.  It is recommended to instead use the strtol() and strtoul() family of functions in new programs.

    */
    int num1 = atoi(argv[1]); // qui non sto controllando il valore di ritorno.. è buona pratica farlo..
    int num2 = atoi(argv[2]);

    int somma = num1 + num2;
    printf("La somma tra %d e %d e': %d\n", num1, num2, somma);

    return 0; // Successo
}
