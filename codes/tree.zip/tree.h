#ifndef TREE_H
#define TREE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/**
 * Struttura del nodo dell'albero binario.
 * Contiene il dato, i puntatori ai figli (left, right) 
 * e il puntatore al genitore (parent) per l'accesso O(1).
 */
typedef struct Node {
    int data;
    struct Node* left;
    struct Node* right;
    struct Node* parent;
} Node;

// --- Operazioni del TDA e Utility ---
Node* create_node(int data);
int num_nodi(Node* root);
int grado(Node* v);
Node* padre(Node* v);

// Funzioni di costruzione dell'albero
Node* insert_left(Node* parent, int data);
Node* insert_right(Node* parent, int data);

// --- Algoritmi di Visita ---
void visita_preordine(Node* root);
void visita_simmetrica(Node* root);
void visita_postordine(Node* root);
void visita_dfs_iterativa(Node* root);
void visita_bfs(Node* root);


//TODO: lasciate come esercizio
// Ricerca di una chiave nel BST (iterativa o ricorsiva)
Node* lookup_node(Node* root, int key);

// Trova il nodo con chiave minima nel sottoalbero
Node* min_node(Node* root);

// Trova il nodo con chiave massima nel sottoalbero
Node* max_node(Node* root);

// Inserimento ordinato in un BST (basato su chiave)
Node* insert_bst(Node* root, int key, int data);


// --- Gestione Memoria ---
void free_tree(Node* root);

#endif
