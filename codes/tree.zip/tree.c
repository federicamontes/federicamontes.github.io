#include "tree.h"

/**
 * Crea e alloca un nuovo nodo dell'albero.
 * Complessità: O(1)
 */
Node* create_node(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("Errore di allocazione memoria.\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->left = NULL;
    newNode->right = NULL;
    newNode->parent = NULL;
    return newNode;
}

/**
 * Restituisce il numero totale di nodi nell'albero.
 * Complessità: O(n) - Visita ricorsiva di tutti i nodi.
 */
int num_nodi(Node* root) {
    if (root == NULL) {
        return 0;
    }
    return 1 + num_nodi(root->left) + num_nodi(root->right);
}

/**
 * Restituisce il numero di figli del nodo v (0, 1 o 2 in un albero BINARIO). Questo funziona SOLO su alberi binari.
 * Complessità: O(1) grazie alla struttura collegata diretta.
 */
int grado(Node* v) {
    if (v == NULL) return 0; // se il nodo è NULL (il nodo non esiste oppure non è allocato), allora ha grado 0
   
    int g = 0; // init della variabile g per il grado, e poi contiamo i figli
    if (v->left != NULL) g++;
    if (v->right != NULL) g++;
    return g;
}

/**
 * Restituisce il padre del nodo v, o NULL se v è la radice.
 * Complessità: O(1) grazie al puntatore esplicito 'parent' memorizzato nel nodo.
 */
Node* padre(Node* v) {
    if (v == NULL) return NULL;
    
    return v->parent;
}

/**
 * Inserisce un figlio sinistro al nodo specificato.
 */
Node* insert_left(Node* parent, int data) {
    if (parent == NULL) return NULL;

    if (parent->left != NULL) {
        printf("Attenzione: figlio sinistro già esistente.\n");
        return parent->left; 
    }

    Node* newNode = create_node(data);
    parent->left = newNode;
    newNode->parent = parent; // Manteniamo la coerenza del puntatore al padre O(1)
    return newNode;
}

/**
 * Inserisce un figlio destro al nodo specificato.
 */
Node* insert_right(Node* parent, int data) {
    if (parent == NULL) return NULL;

    if (parent->right != NULL) {
        printf("Attenzione: figlio destro già esistente.\n");
        return parent->right;
    }

    Node* newNode = create_node(data);
    parent->right = newNode;
    newNode->parent = parent; // Coerenza del puntatore al padre O(1)
    return newNode;
}

// insert_left:  &(parent->left)
void insert_child(Node **link, Node *parent, int data) {

	if (link == NULL || parent == NULL) return;

	if (*link != NULL) {
		printf("C'è già un sottoalbero destro-sinistro!");
		return;
	}

	Node *newNode = create_node(data);
	newNode->parent = parent;
	*link = newNode;

}

// Come cambia la funzione di inserimento del figlio, se dobbiamo chiamare insert_child generica
// similarità con le doubly linked list
Node *insert_left_v2(Node *parent, int data) {

	if (parent == NULL) return NULL;

	insert_child(&(parent->left), parent, data);

	return parent->left;
}

// ==========================================
// VISITE IN PROFONDITÀ (DFS) - RICORSIVE
// ==========================================

// visita utile quando si deve duplicare un albero
void visita_preordine(Node* root) {
    if (root == NULL) return;
    printf("%d ", root->data);      // Visita nodo
    visita_preordine(root->left);   // Sottoalbero sinistro
    visita_preordine(root->right);  // Sottoalbero destro
}

// visita utile per gestire BST
void visita_simmetrica(Node* root) {
    if (root == NULL) return;
    visita_simmetrica(root->left);  // Sottoalbero sinistro
    printf("%d ", root->data);      // Visita nodo
    visita_simmetrica(root->right); // Sottoalbero destro
}


// visita utile per la cancellazione di un albero -- vedi funzione free_tree
void visita_postordine(Node* root) {
    if (root == NULL) return;
    visita_postordine(root->left);  // Sottoalbero sinistro
    visita_postordine(root->right); // Sottoalbero destro
    printf("%d ", root->data);      // Visita nodo
}

// ==========================================
// VISITA IN PROFONDITÀ (DFS) - ITERATIVA
// Sfrutta una Pila (Stack) esplicita
// ==========================================

#define STACK_SIZE 100


// In questa visita, in preordine, lo stack viene usato esplicitamente anziché sfruttare lo stack implicito alla ricorsione
// La complessità temporale rimane O(n) perché attraversiamo tutti i nodi, quella spaziale è O(h) con h altezza dell'albero.
void visita_dfs_iterativa(Node* root) {

    if (root == NULL) return;

    Node* stack[STACK_SIZE];
    int top = -1; // init dell'indice: lo stack è vuoto

    stack[++top] = root; // incremento top e push della radice
    // perché scrivo ++top?


    while (top >= 0) { // finché l'albero non è finito
        Node* u = stack[top--]; // Pop del nodo e decremento top
	// perché scrivo top--?

        if (u != NULL) {

	    // VISITA IL NODO
            printf("%d ", u->data); //stampo il campo data

            // Nota: inseriamo prima il destro e poi il sinistro → INVARIANTE LIFO 
            // affinché il sinistro venga estratto ed elaborato per primo (LIFO)
            if (u->right != NULL && top < STACK_SIZE - 1) {
                stack[++top] = u->right; // push del figlio destro
            }
            if (u->left != NULL && top < STACK_SIZE - 1) {
                stack[++top] = u->left; // push del figlio sinistro
            }
        }
    }
}

// ==========================================
// VISITA IN AMPIEZZA (BFS)
// Sfrutta una Coda (Queue) circolare/lineare
// ==========================================

#define QUEUE_SIZE 100


// Per la visita BFS si usa una Coda ausiliaria
// La complessità temporale è O(n), quella spaziale è O(w), con w larghezza massima dell'albero
void visita_bfs(Node* root) {
    if (root == NULL) return;

    Node* queue[QUEUE_SIZE];
    int head = 0, tail = 0;

    // Enqueue della radice
    queue[tail++] = root;

    while (head < tail) { // finché l'albero non è finito
        Node* u = queue[head++]; // Dequeue
	// head avanza quando preleviamo un elemento dalla coda

        if (u != NULL) {
            printf("%d ", u->data);

	    // tail avanza quando aggiungiamo un nodo (riempiendo la coda)
            if (u->left != NULL && tail < QUEUE_SIZE) {
                queue[tail++] = u->left; // Enqueue figlio sinistro
            }
            if (u->right != NULL && tail < QUEUE_SIZE) {
                queue[tail++] = u->right; // Enqueue figlio destro
            }
        }
    }
}

// ==========================================
// GESTIONE MEMORIA
// ==========================================

void free_tree(Node* root) {
    if (root == NULL) return;
    free_tree(root->left);
    free_tree(root->right);
    free(root);
}


/* FUNZIONI LASCIATE PER ESERCIZIO */

// 1. Ricerca (Lookup): Sfrutta la proprieta' del BST (chiavi minori a sinistra, maggiori a destra)
Node* lookup_node(Node* root, int key) {

	//caso base

	// passi ricorsivi condizionali (if - else)
	// mi devo chiedere se devo cercare a sinistra o a destra..
}


// 2. Minimo: Sfruttare le proprieta' del BST per capire dove andare a cercare il minimo
Node* min_node(Node* root) {



}


// 3. Massimo: Sfruttare le proprieta' del BST per capire dove andare a cercare il massimo
Node* max_node(Node* root) {


}

// 4. Inserimento ordinato nel BST: procedura ricorsiva per inserire mantenendo l'invariante dell'ordinamento delle chiavi
Node* insert_bst_rec(Node* root, Node* parent, int key, int data) {

	// caso base: creo e inserisco il nodo


	// passo ricorsivo condizionale in base all'ordinamento della chiave


}
