#include <stdio.h>

int main(int argc, char *argv[]) {

	printf("Numero di parametri %d -- parametri %s \n", argc, argv[0]);
	// argc è il numero di parametri del programma, è sempre almeno 1 perché contiene il nome del programma eseguibile
	for (int i=0; i < argc; i++) {
		if (i==0) {
			printf("Nome del programma: %s\n", argv[i]);
		} else {
			printf("Parametro %d è %s \n", i, argv[i]);
		}
	}

	return 0;
}
