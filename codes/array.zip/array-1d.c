#include <stdio.h>

#define CAPACITA 10

int main(void) {
    // Inizializzazione parziale (gli elementi rimanenti saranno 0 o valori spuri!)
    int voti[CAPACITA] = {28, 30, 24, 22, 18};
    
    printf("=== Voti === \n");
    for (int i = 0; i < CAPACITA; i++) {
	printf("voti[%d] = %d \n", i, voti[i]);
    }

    int n_elementi = 0; // se ho un array con valori 0 o non ancora riempiti devo contare gli elementi con valori effettivamente validi
	// la validità di un valore dipende dal dominio del problema: per questo esempio non ha senso considerare voti <= 0
    for (int i = 0; i < CAPACITA; i++) {
	if (voti[i] != 0) {
		n_elementi++;
	}
    }

    // calcolo media e max
    int somma = 0;
    int max = voti[0];

    for (int i = 0; i < n_elementi; i++) { // che succede se scorro fino a CAPACITA?
	somma += voti[i];
	if (voti[i] > max) {
		max = voti[i];
	} //end if
	
    } // end for

    double avg = (double)somma / n_elementi; // casting esplicito!

    printf("Somma: %d\n", somma);
    printf("Media: %lf \n", avg);
    printf("voti[10] %d\n", voti[10]); // che succede se tento di accedere valori fuori dall'array?
    return 0;
}

