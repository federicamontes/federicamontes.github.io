#include <stdio.h>

// Sintassi C99 per il passaggio di matrici: le dimensioni 'r' e 'c' devono precedere l'array
void riempiMatrice(int r, int c, int mat[r][c]) {
    int contatore = 1;
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            mat[i][j] = contatore++;
        }
    }
}

void stampaMatrice(int r, int c, int mat[r][c]) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            printf("%d ", mat[i][j]);
        }
        printf("\n");
    }
}

// Calcolo della trasposta: da una matrice (r x c) a una (c x r)
void trasponiMatrice(int r, int c, int src[r][c], int dest[c][r]) {
    for (int i = 0; i < r; i++) {
        for (int j = 0; j < c; j++) {
            dest[j][i] = src[i][j];
        }
    }
}

int main(void) {
    int R = 3, C = 4;
    int A[R][C];
    int A_T[C][R]; // Matrice trasposta

    riempiMatrice(R, C, A);
    printf("=== Matrice A (%dx%d) ===\n", R, C);
    stampaMatrice(R, C, A);

    trasponiMatrice(R, C, A, A_T);
    printf("\n=== Trasposta A_T (%dx%d) ===\n", C, R);
    stampaMatrice(C, R, A_T);

    return 0;
}
