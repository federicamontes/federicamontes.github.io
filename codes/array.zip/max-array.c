#include <stdio.h>

#define DIM 5 // Dimensione fissa dell'array nota a tempo di compilazione

int main(void) {
    int valori[DIM];

    // Riempimento dell'array tramite input utente
    printf("Inserisci %d numeri interi:\n", DIM);
    for (int i = 0; i < DIM; i++) {
        printf("Elemento %d: ", i);
        scanf("%c", &valori[i]); // scanf su interi ripetuta per DIM volte
    }

    // Ricerca del valore massimo
    int massimo = valori[0]; 
    for (int i = 1; i < DIM; i++) {
        if (valori[i] > massimo) {
            massimo = valori[i]; // Aggiorniamo il massimo se ne troviamo uno piu' grande
        }
    }


    printf("\nIl valore massimo inserito e': %d\n", massimo);

    return 0;
}
