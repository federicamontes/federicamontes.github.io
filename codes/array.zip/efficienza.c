#include <stdio.h>
#include <stdlib.h>
#include <time.h>

#define RIGHE 10000
#define COLONNE 10000

/**
Questo codice è puramente dimostrativo, serve a far capire cosa vuol dire dal punto di vista prestazionale
e della macchina sottostante, scandire una matrice per righe o per colonne. 
In sistemi che memorizzano gli array D-dimensionali in modo row-major (ossia srotolando la matrice per righe sulla memoria lineare),
scorrere per righe o per colonna fa differenza.
Scorrendo per righe, seguiamo la naturale memorizzazione della matrice (il processore applicherà una serie di ottimizzazioni
che vedrete nei prossimi corsi, come il pre-fetching..).
Scorrendo per colonne, stiamo saltando di ixN posizioni (i indice di riga, N numero di colonne..) alla volta, creando
veramente dei salti progressivi in cui andiamo avanti e indietro nella memoria, per questo è meno performante.

*/


int mat[RIGHE][COLONNE];

int main(void) {
    long long int somma = 0;
    clock_t inizio, fine;
    double tempo_righe, tempo_colonne;

    // Inizializzazione della matrice
    for (int i = 0; i < RIGHE; i++) {
        for (int j = 0; j < COLONNE; j++) {
            mat[i][j] = 1;
        }
    }

    // -------------------------------------------------------------
    // SCORRIMENTO PER RIGHE (C-friendly: [i][j] con i ciclo esterno)
    // -------------------------------------------------------------
    somma = 0;
    inizio = clock();

    for (int i = 0; i < RIGHE; i++) {          // Riga
        for (int j = 0; j < COLONNE; j++) {    // Colonna
            somma += mat[i][j];
        }
    }

    fine = clock();
    tempo_righe = (double)(fine - inizio) / CLOCKS_PER_SEC;
    printf("Scorrimento per RIGHE:   %.4f secondi (Somma: %lld)\n", tempo_righe, somma);

    // -------------------------------------------------------------
    // SCORRIMENTO PER COLONNE (Cache-unfriendly: [i][j] con j ciclo esterno)
    // -------------------------------------------------------------
    somma = 0;
    inizio = clock();

    for (int j = 0; j < COLONNE; j++) {        // Colonna
        for (int i = 0; i < RIGHE; i++) {      // Riga
            somma += mat[i][j];
        }
    }

    fine = clock();
    tempo_colonne = (double)(fine - inizio) / CLOCKS_PER_SEC;
    printf("Scorrimento per COLONNE: %.4f secondi (Somma: %lld)\n", tempo_colonne, somma);

    // Calcolo del rapporto di prestazione
    printf("\n--> Lo scorrimento per righe e' stato circa %.1fx piu' veloce!\n", tempo_colonne / tempo_righe);

    return 0;
}
