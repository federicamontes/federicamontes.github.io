#include <stdio.h>
#include <math.h>
#include <stdint.h>

#define N  5
int main(void)
{
  char name[N];

  name[0] = 'P';
  name[1] = 'i';
  name[2] = 'p';
  name[3] = 'p';
  name[4] = 'o';
  name[5] = '\0';
  // qual è il problema qui?

  // %s nella printf informa che si sta leggendo un array di char, un byte alla volta finché non si incontra '\0'
  printf("%s \n",name);
  return(0);
    
}
