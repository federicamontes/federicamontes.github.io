#include <stdio.h>
#include <string.h>

#define LUNGHEZZA_MAX 50

int main(void) {
    // Inizializzazione esplicita vs sintassi compatta
    char saluto[] = "Ciao"; // Il compilatore aggiunge '\0' rendendolo di dimensione 5
    unsigned long dim = sizeof(saluto)/sizeof(char);
    printf("Stringa: %s -- sizeof %lu -- strlen %lu \n", saluto, sizeof(saluto)/sizeof(char), strlen(saluto));
    printf("Contenuto cella per cella:\n");
    for (int i = 0; i < dim; i++) {
        if (saluto[i] == '\0') { // se sono arrivato alla fine della stringa
            printf("saluto[%d] = '\\0' (ASCII 0)\n", i);
        } else {
            printf("saluto[%d] = '%c'\n", i, saluto[i]);
        }
    }

    // Lettura sicura di una stringa con spazi usando fgets
    char frase[LUNGHEZZA_MAX];
    printf("\nInserisci una frase: ");
    if (fgets(frase, LUNGHEZZA_MAX, stdin) != NULL) {
        // Rimozione del carattere newline '\n' catturato da fgets!
        printf("Stringa letta da input: %s \n", frase);
	for (int i = 0; ; i++) { // come ulteriore sicurezza rimuoviamo il "\n" sostituendolo con '\0' (non obbligatorio ma buona pratica)
            if (frase[i] == '\n') {
                frase[i] = '\0'; //sostituisco \n con il terminatore di stringa!
                break;
            }
        }
        printf("Hai inserito: \"%s\"\n", frase);
    }

    return 0;
}
