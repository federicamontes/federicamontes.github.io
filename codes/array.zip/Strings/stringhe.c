#include <stdio.h>
#include <string.h>

#define MAX_BUF 100

int main(void) {
    char s1[MAX_BUF] = "Roma";
    char s2[] = "Tor Vergata";
    char risultato[MAX_BUF] = "";

    // strlen: calcolo della lunghezza (escluso '\0')
    printf("Lunghezza di s1 (\"%s\"): %lu\n", s1, strlen(s1));

    // strcpy: copia della stringa
    strcpy(risultato, s1); // presuppone che la stringa destinazione abbia spazio a sufficienza!
    printf("Dopo strcpy: risultato = \"%s\"\n", risultato);

    // strcat: concatenazione stringhe
    strcat(risultato, " ");
    strcat(risultato, s2); // presuppone che la stringa destinazione abbia spazio a sufficienza!
    printf("Dopo strcat: risultato = \"%s\"\n", risultato);
    
   // se volete lavorare con funzioni "safe" preferite strncat, strncpy... 


    // strcmp: confronto tra stringhe
    char p1[] = "Algoritmi";
    char p2[] = "Algoritmi";
    char p3[] = "C89";
	
    if (strcmp(p1, p2) == 0) {
        printf("\n\"%s\" e \"%s\" sono IDENTICHE.\n", p1, p2);
    }

    /* strcmp controlla i caratteri da sinistra a destra, uno per volta (ASCII)
    Dal man:
    The strcmp() function compares the two strings s1 and s2.  The locale is not taken into account (for a locale-aware comparison, see strcoll(3)).  The comparison is done us‐
       ing unsigned characters.

       strcmp() returns an integer indicating the result of the comparison, as follows:

       •  0, if the s1 and s2 are equal;

       •  a negative value if s1 is less than s2;

       •  a positive value if s1 is greater than s2.

       The strncmp() function is similar, except it compares only the first (at most) n bytes of s1 and s2.
    
    Cosa succede in questo confronto?
    p1 inizia con 'A' (il cui valore ASCII è 65), p3 inizia con 'C' (il cui valore ASCII è 67).
    La strcmp ferma subito il confronto al primo carattere differente e calcola la differenza: 65 - 67 = -2.
    In generale la strcmp controlla char per char, si fermerà al primo diverso tra le due stringhe e le compara in codice ASCII
    per questo stringhe uguali avranno risultato 0
    */
    if (strcmp(p1, p3) < 0) { // la condizione mostrata a lezione era invertita! scusate!
        printf("\"%s\" PRECEDE \"%s\"\n", p1, p3);
    } else{
	printf("\"%s\" SEGUE \"%s\"\n", p1, p3);
    }

    return 0;
}
