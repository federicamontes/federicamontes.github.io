#include <stdio.h>

// Funzione per stampare un array 1D
void stampaArray(int v[], unsigned long n) {
    // provate a stampare la sizeof(v) in questa funzione: cosa succede?
    printf("[ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");
}

// Funzione che inverte l'array sul posto (in-place)
void inverteArray(int v[], unsigned long n) {
    for (int i = 0; i < n/2; i++) {
        int temp = v[i];
        v[i] = v[n - 1 - i];
        v[n - 1 - i] = temp;
    }
}

int main(void) {
    int numeri[] = {1, 2, 3, 4, 5, 6};
    /**
	scrivere sizeof(numeri) vuol dire prendere il numero di elementi (6) e moltiplicare per la sizeof(type) memorizzato (int in questo caso)
	e quindi sizeof(numeri) è 24
	per ottenere la dimensione effettiva in numero di elementi bisogna dividere per la sizeof(type)
    */
    unsigned long n = sizeof(numeri)/sizeof(numeri[0]); 
    printf("Dimensione %lu -- #elementi: %lu \n",sizeof(numeri), n);

    printf("Array originale: ");
    stampaArray(numeri, n);

    inverteArray(numeri, n);

    printf("Array invertito: ");
    stampaArray(numeri, n);

    return 0;
}
