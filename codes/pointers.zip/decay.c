#include <stdio.h>


/*
Quando un array viene passato a una funzione, decade automaticamente a un semplice puntatore (type *), 
perdendo l'informazione sulla sua dimensione totale
*/
void stampaDimensione(int a[]) { //golden rule: quando si passano array ad una funzione bisogna sempre portarsi dietro il numero di elementi
    // In questo blocco a non e' un array, ma un int* !
    printf("In funzione  - sizeof(a): %lu byte (dimensione del puntatore!)\n", 
           sizeof(a));
}

int main(void) {
    int v[10] = {0}; // Allocati 10 int = 40 byte (su architettura 32/64 bit con int a 4 byte)

    printf("Nel main     - sizeof(v): %lu byte (dimensione dell'array intero)\n", 
           sizeof(v));
    
    stampaDimensione(v);

    return 0;
}
