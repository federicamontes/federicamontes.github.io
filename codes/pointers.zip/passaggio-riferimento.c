#include <stdio.h>


// passaggio per valore, cosa succede quando torniamo nel main?
void foo(int a)
{
  a = a + 1;
  printf("Dentro foo=%d\n",a);
}

/* se passo una variabile per riferimento, ossia passo l'indirizzo di quella variabile
sto lavorando col puntatore a quella variabile, non più con il suo valore!
*/
void foo_ref(int *a)
{
  *a = *a + 1;
  printf("Dentro foo_ref=%d\n",*a);
}

int main(void)
{
  int n = 10;

  printf("Dentro main, prima di foo()=%d\n",n);
  foo(n);
  printf("Dentro main, dopo foo()=%d\n",n);

  foo_ref(&n); // che succede qui?
  printf("Dentro main, dopo foo_ref()=%d\n",n);
  return 0;
}
  
