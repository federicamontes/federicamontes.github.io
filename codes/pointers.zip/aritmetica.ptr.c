#include <stdio.h>
#define N 3

int main(void) {
    int arr[N] = {10, 20, 30};
    int *p_int = arr;
    char *p_char = (char *)arr;

    int *p2 = &arr[2];
    printf("=== Aritmetica dei Puntatori ===\n");
    printf("Indirizzo base p_int: %p\n", (void *)p_int);
    printf("p_int + 1:           %p (incremento di %lu byte)\n", 
           (void *)(p_int + 1), sizeof(int)); // p_int + 1 punterà ad un indirizzo spostato di 1 x sizeof(int) byte

    printf("Indirizzo base p_char: %p\n", (void *)p_char);
    printf("p_char + 1:          %p (incremento di %lu byte)\n", 
           (void *)(p_char + 1), sizeof(char)); // p_char punterà ad un indirizzo spostato di 1 x sizeof(char) byte

    // che succede se sommo due puntatori (anche dello stesso tipo)?

    unsigned long diff = p2 - p_int; // il tipo ptrdiff_t nelle slides non è altro che un unsigned long..
    printf("Distanza: %lu elementi \n",diff);
    
    p_char++;
    printf("Distanza tra p e p_int %lu\n", p_char - p_int);

    /**
	Equivalenza di indicizzazione: arr[i], *(arr + i) e la sintassi insolita i[arr] 
	generano esattamente la stessa operazione a livello macchina. 
	Cosa vuol dire i[arr]? Poiché la somma gode della proprietà commutativa (arr + i == i + arr), anche i[arr] è una sintassi valida in C.
	In pratica è poco usato..
    */

    printf("\n=== Equivalenza arr[i] e *(arr + i) ===\n");
    for (int i = 0; i < N; i++) {
        printf("arr[%d] = %d | *(arr + %d) = %d | %d[arr] = %d\n", 
               i, arr[i], i, *(arr + i), i, i[arr]);
    }

    return 0;
}
