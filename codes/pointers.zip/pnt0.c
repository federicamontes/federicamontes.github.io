#include <stdio.h>

int main(void)
{
    int n;
    int *a;

    //cosa succede se provo ad accedere un puntatore non inizializzato? Concetto di wild pointer e undefined behavior..

    // --- STEP 1: Inizializzazione e primo puntamento ---
    n = 8;
    a = &n; //Alias in memoria, tutte le modifiche sul valore di n si ripercuotono sul valore puntato da a
    
    printf("=== STEP 1: Valore iniziale ===\n");
    printf("n  = %d\n", n);
    printf("*a = %d\n", *a);
    printf("\n");

    // --- STEP 2: Incremento della variabile originale ---
    n++;
    printf("=== STEP 2: Dopo n++ ===\n");
    printf("n  = %d\n", n);
    printf("*a = %d\n", *a);
    printf("\n");

    printf("Indirizzo di n %p \t Puntatore a %p \n ", &n, a); // uso del formattatore %p per stampare indirizzi in esadecimale

    (*a)++; // perché sono importanti le parentesi?
    printf("=== STEP 3: Dopo (*a)++ ===\n");
    printf("n  = %d\n", n);
    printf("*a = %d\n", *a);
    printf("\n");
    
    // --- STEP 4: Controllo del puntatore NULL e Indirizzo ---
    printf("=== STEP 4: Verifiche e Indirizzi ===\n");
    if (a == NULL) { 
       printf("Puntatore non valido! \n");
    } else {
	printf("Valore puntato da a %d \n", *a);
    }

    // Qual è la differenza tra controllare if (a == NULL) e if (*a == 0)? 
    a = NULL; //che succede se il puntatore ha un valore NULL?
    //a = (int *)1; // che succede se assegno un indirizzo arbitrario ad a?
    printf("Puntatore a %p \n", a);
    printf("Valore puntato da a %d \n", *a);
    // cos'è succeso qui? Perché si verifica un segmentation fault?

    return 0;
}
