#include <stdio.h>
#include <stdlib.h>

/*
Finora le variabili che abbiamo visto (come int v[10]) venivano allocate sullo Stack. 
Lo Stack è gestito automaticamente, ma ha due grandi limiti: ha dimensione fissa ed è temporaneo (scompare appena la funzione finisce). 
L'Heap è una grande area di memoria libera dove possiamo chiedere spazio on demand a runtime 
e far sì che l'area di memoria sopravviva anche quando la funzione termina.
*/




/**
 * Funzione che alloca un array dinamico di interi e lo inizializza.
 * 
 * @param n Dimensione dell'array da allocare
 * @return Puntatore all'area di memoria allocata (oppure NULL in caso di errore)
 */
int* crea_e_inizializza_array(int n) {
    if (n <= 0) {
	printf("Dimensione negativa!");
	return NULL;
    }
    // Facciamo il cast (int *) per dire al compilatore che tratteremo quei byte come interi
    int *v = (int *) malloc(n * sizeof(int));

    // Controllo di errore: La malloc può fallire se la RAM è piena. Controllare se restituisce NULL non è opzionale, 
    // è un obbligo di programmazione sicura
    if (v == NULL) return NULL;

    for (int i = 0; i < n; i++) {
	v[i] = i;
    }

    return v;
}

int main(void) {
    int n = 10;
        
    // CHIAMATA ALLA MALLOC
    int *v = crea_e_inizializza_array(n);

    // Controllo d'errore
    if (v == NULL) {
        fprintf(stderr, "Errore: Allocazione memoria fallita!\n");
        return 1;
    }

    // STAMPA INDIRIZZO 
    printf("Memoria allocata nell'Heap all'indirizzo: %p\n", (void *)v);

    // USO DELL'ARRAY, posso indicizzarlo come un array statico (zucchero sintattico!)
    printf("Contenuto array: [ ");
    for (int i = 0; i < n; i++) {
        printf("%d ", v[i]);
    }
    printf("]\n");

    // LIBERAZIONE DELLA MEMORIA (Fondamentale!)
    // Se togliessimo free(v), ad ogni ciclo perderemmo n * sizeof(int) byte (Memory Leak)
    free(v); // posso fare la free() anche se non ho usato malloc() dentro questa funzione perché la memoria è nell'heap e non nello stack!

    // Cosa succede se eseguo free(p) e poi tento di fare printf("%d", *p);? Concetto di Dangling Pointer..

    v = NULL; // Buona pratica (ma non obbligatorio): azzeriamo il puntatore dopo la free per evitare dangling pointers

    printf("Memoria liberata correttamente con free()\n\n");
  

    return 0;
}
