// test_warning2.c
#include <stdio.h>

int main(void) {
    int totale; 
    
    totale = totale + 10;
    printf("Totale: %d\n", totale);
    return 0;
}

/**
Compilazione senza flag: "gcc file.c -o program", 
poi compila usando -O2 e vedi se cambia qualcosa.
Che succede all'output?
Infine compila con -Wall e -Wextra e vedi cosa succede. Abbiamo un messaggio di warning, ma l'eseguibile viene creato lo stesso!

È importante imparare a leggere i warning perché in questo modo si impara a scrivere codice robusto.

*/
