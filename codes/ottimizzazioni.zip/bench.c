#include <stdio.h>
#include <time.h> // header file per tipo di dato clock_t e per funzione clock()

int main(void) {
    clock_t start = clock(); // utilities per calcolare il tempo all'istante di invocazione

    long sum = 0;
    for (long i = 0; i < 1000000000L; i++) {
        sum += i; // Calcolo pesante
    }

    clock_t end = clock();
    double time_spent = (double)(end - start) / CLOCKS_PER_SEC;
 
// Esegui il codice senza questa printf, poi togli il commento
//    printf("Stampiamo sum %ld \n", sum);   
    printf("Tempo impiegato: %f secondi\n", time_spent);
    
    return 0;
}


/**
Compilare il codice con flag -O0 e poi con -O2

1. Con -O0 la CPU compie davvero 1 miliardo di iterazioni in sequenza: incrementa l'indice, somma i a sum, sottostà ai salti condizionali del ciclo for. 
Anche se sum non verrà mai più usata.

2. Con -O2, il compilatore si rende conto che la variabile sum usata nel ciclo, poi non viene mai più utilizzata, rendendo il blocco del for inutile! 
Il compilatore cancella completamente il ciclo dal codice macchina finale. 
Non c'è nessun miliardo di somme eseguito a runtime; il programma salta direttamente alla fine, impiegando 0.00002 secondi.

3. Se forzo la stampa di sum, costringiamo il compilatore ad effettuare tutte le iterazioni! Oppure no...? 
Il compilatore si accorge della prevedibilità del calcolo e applica (probabilmente..) la formula di Gauss (n-1 x n)/2


*/
