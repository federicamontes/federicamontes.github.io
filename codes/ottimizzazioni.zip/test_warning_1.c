// test_warning1.c
#include <stdio.h>

int main(void) {
    int x = 5;

    // Errore tipico: un solo '='
    if (x = 0) {
        printf("x e' zero\n");
    } else {
        printf("x NON e' zero (Valore di x: %d)\n", x);
    }
    return 0;
}



/** Compilazione senza flag: "gcc file.c -o program", 
poi compila usando -O2 e vedi se cambia qualcosa.
Infine compila con -Wall e -Wextra e vedi cosa succede. Abbiamo un messaggio di warning, ma l'eseguibile viene creato lo stesso!

Che succede se compilo anche con -Werror?


*/
