// test_linker.c
#include <stdio.h>

// Prototipo dichiarato, ma funzione mai definita!
void calcola_somma(int a, int b);

int main(void) {
    printf("Eseguo la funzione...\n");
    calcola_somma(3, 4);
    return 0;
}

/**
Qui non importa quanti flag di compilazione userete, riceverete sempre un errore
/usr/bin/ld: /tmp/cc7N6Sgw.o: in function `main':
test_linker.c:(.text+0x22): undefined reference to `calcola_somma'
collect2: error: ld returned 1 exit status

Il problema non è del compilatore, ma del LINKER. Infatti sta cercando di risolvere il riferimento a calcola_somma(int a, int b), 
ma non la trova da nessuna parte, perché sebbene sia dichiarato il prototipo, la sua definizione non c'è da nessuna parte.
*/
