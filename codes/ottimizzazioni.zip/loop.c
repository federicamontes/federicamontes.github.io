#include <stdio.h>


/* In questo codice c'è un ciclo for che va da 1, finché i è positivo, e va avanti di step 100000000
Non ci sono operazioni nel ciclo, come si comporta il compilatore?
Prova a compilare col comando gcc classico come visto a lezione.
Poi prova a compilare aggiungendo -O0: "gcc -O0 filename.c -o program"
Poi prova a compilare aggiungengo -O2, che succede?

*/
int main(void) {
    printf("Inizio ciclo...\n");
    
    // Proviamo a far andare in overflow un int
    for (int i = 1; i > 0; i += 100000000) {
        // Nessun'operazione complessa
    }
    
    printf("Ciclo terminato con successo!\n");
    return 0;
}



/* Con -O0 il codice viene eseguito in maniera letterale, dopo 21 iterazioni, il valore supera la capacità massima di un int a 32 bit (INT_MAX, circa 2,14 miliardi), 
provocando un overflow a livello hardware (il numero "fa il giro" e diventa negativo). A quel punto la condizione i > 0 diventa falsa, 
il ciclo si interrompe e il programma termina con successo.

loop.c:6:30: warning: iteration 21 invokes undefined behavior [-Waggressive-loop-optimizations]
    6 |     for (int i = 1; i > 0; i += 100000000) {
      |                            ~~^~~~~~~~~~~~
* Il flag -O2 adotta un'ottimizzazione aggressiva ma ottimistica: Dato che l'overflow di un int è un comportamento non definito, 
io assumo per ipotesi che l'overflow non si verificherà mai. Se i parte da 1 e viene incrementato sempre di un valore positivo (+ 100000000) 
senza poter mai andare in overflow, allora la condizione del ciclo i > 0 sarà matematicamente sempre vera per l'eternità. E quindi il ciclo viene interpretato come ciclo infinito.
* Il warning -Waggressive-loop-optimizations ti sta avvisando esattamente di questo: il compilatore si è accorto che l'iterazione 21 sforerebbe i limiti e, 
basandosi sull'assenza di overflow, ha cambiato il modo in cui gestisce le condizioni del ciclo.

Come risolviamo questo problema per poter compilare con -O2 senza incorrere in un ciclo infinito?

*/

