#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person {
  char *name;
  int age;
  int height;
  int weight;
} Person;


// sto passando la struct per indirizzo per inizializzarne i campi e rendere persistenti le modifiche al chiamante
void struct_init(Person **who, char *name, int age, int height, int weight)
{

  (*who)->name = name;
  (*who)->age  = age;
  (*who)->height  = height;
  (*who)->weight = weight;

    
}


void print_person(Person *who)
{
  if (who == NULL) return;
  printf("Nome: %s\n",who->name);
  printf(" Età: %d\n",who->age);
  printf("Altezza: %d\n",who->height);
  printf("Peso: %d\n",who->weight);
}


int main(void)
{
  Person  *johndoe;
  johndoe = malloc(sizeof(Person));
  if (johndoe == NULL) {
    fprintf(stderr,"Error in allocation\n");
    return 1;
  }
  struct_init(&johndoe,"John Doe",30,180,90);
  
  print_person(johndoe); 

  free(johndoe);
  return(0);
    
}
