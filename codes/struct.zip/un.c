#include <stdio.h>

// Definizione della union: tutti i membri condividono la STESSA cella di memoria
/*
I campi a differenza delle struct hanno tutti lo stesso indirizzo di memoria,
rendendo accessibile e utilizzabile un solo campo alla volta della union.
Si utilizzando per motivi di ottimizzazioni dello spazio poiché una union
ha dimensione uguale alla dimensione del campo maggiore.
*/
union Dato {
    int i;
    double d;
    char c;
};

int main(void) {
    union Dato u;

    // 1. Dimensione della Union (coincide con double, il tipo piu' grande = 8 byte)
    printf("=== DIMENSIONE IN RAM ===\n");
    printf("sizeof(union Dato): %lu byte\n", sizeof(u));
    printf("sizeof(int): %lu | sizeof(double): %lu | sizeof(char): %lu\n\n",
           sizeof(int), sizeof(double), sizeof(char));

    // 2. Tutti i membri partono dallo STESSO indirizzo di memoria
    printf("=== INDIRIZZI DI MEMORIA ===\n");
    printf("&u.i = %p\n", (void*)&u.i);
    printf("&u.d = %p\n", (void*)&u.d);
    printf("&u.c = %p\n\n", (void*)&u.c);

    // 3. Sovrascrittura dei dati (Overwriting)
    printf("=== COMPORTAMENTO DATI ===\n");
    u.i = 10;
    printf("Scritto u.i -> u.i vale: %d\n", u.i);

    u.d = 220.5; // Questa scrittura SOVRASCRIVE il valore di u.i!
    printf("Scritto u.d	-> u.d vale: %.5f\n", u.d);
    printf("Valore corrotto di u.i dopo la scrittura in u.d: %d\n", u.i); //stiamo leggendo i byte di un double interpretandoli come un int

    return 0;
}
