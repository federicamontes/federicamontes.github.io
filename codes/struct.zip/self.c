#include <stdio.h>
#include <stdlib.h>


/*
Le struct autoriferite contengono come campo un puntatore a se stesse
DEVE esserci un puntatore e non una variabile semplice poiché
altrimenti la size della struct sarebbe infinita.
*/
typedef struct Node {
	int data;
	struct Node *next; //ptr a un oggetto dello stesso tipo!

} Node;


int main(void) {

	Node *head = malloc(sizeof(Node));
	if (head == NULL) return 1;
	head->data = 10;
	head->next = NULL;

	head->next = malloc(sizeof(Node));
	if (head->next == NULL) return 1;
	head->next->data = 20;
	head->next->next = NULL;

	printf("head %p ------> head->next %p \n", head, head->next);

	// free memory...
// perché liberare la memoria in questo modo è sbagliato?
//	free(head);
//	free(head->next);

	Node *temp = head->next;
	free(head);
	free(temp);

	return 0;
}
