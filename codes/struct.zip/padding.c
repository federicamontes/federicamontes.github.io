#include <stdio.h>


/**
I processori leggono una word alla volta (la word è tipicamente di 4 o 8 byte)
Quindi quando i campi sono definiti in una struct come per struct Esempio2, il processore legge un char (1 byte)
ma intanto si aspetta di doverne leggere 4 alla volta, e quindi inserirà i 3 byte rimanenti per leggere
la prossima word come "padding".
L'intero int b è di 4 byte (sulla mia macchina) e quindi la lettura è allineata, il successivo char c è 1 byte
e quindi aggiungerà altri 3 byte di padding per completare la lettura di una word.
Il risultato è che in memoria la struct Esempio2 avrà dimensione 12 byte (char 1 + padding 3 + int 4 + char 1 + padding 3)

La struct Esempio è definita elencando i campi in ordine decrescente di dimensione in modo tale
da ridurre la dimensione della memoria in quanto si riduce il padding totale che viene inserito 
dal processore per leggere le word.
*/
struct Esempio {
	int b;
	char a;
	char c;
};

struct Esempio2 {
        char a;
        int b;
        char c;
};



int main(void) {
	
	printf("Size of Esempio is  %lu\n", sizeof(struct Esempio));

	return 0;
}
