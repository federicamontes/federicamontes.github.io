#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct person {
  char *name;
  int age;
  int height;
  int weight;
} Person;

Person *create(char *name, int age, int height, int weight)
{
  Person *who;

  // la struct ha una propria size, usando sizeof(Person) si alloca abbastanza spazio da contenere
  // la struct e i suoi campi
  who = (Person *) malloc(sizeof(Person));
  if (who == NULL) return NULL; 
  // notazione freccia "->" per accedere ai campi usando il puntatore a struttura
  // equivalente a fare (*who).name ....
  who->name = name;
  who->age  = age;
  who->height  = height;
  who->weight = weight;
  return who;
    
}


void print_person(Person *who)
{
  if (who == NULL) return;
  printf("Nome: %s\n",who->name);
  printf(" Età: %d\n",who->age);
  printf("Altezza: %d\n",who->height);
  printf("Peso: %d\n",who->weight);
}


int main(void)
{
  // puntatore a struct di tipo Person
  Person  *johndoe;

  johndoe = create("John Doe",30,180,90);
  if (johndoe == NULL) {
    fprintf(stderr,"Malloc failure\n");
    return 1;
  }
  print_person(johndoe); 

  free(johndoe);
  return 0;
    
}
