#include <stdio.h>
#include <stdlib.h>

// typedef serve a creare un tipo di dato custom
// e ad usare successivamente la struct come tipo di dato a sé stante
// ossia senza scrivere sempre struct person p;
typedef struct person {
  char *name;
  int age;
  int height;
  int weight;
} Person;



void print_person(Person who)
{
 
  printf("Nome: %s\n",who.name);
  printf("Età: %d\n",who.age);
  printf("Altezza: %d\n",who.height);
  printf("Peso: %d\n",who.weight);
}


int main(void)
{
  // posso usare Person perché è il nome dato attraverso typedef
  Person johndoe;

  // notazione punto "." per accedere ai campi della variabile Person
  johndoe.name = "John Doe";
  johndoe.age  = 30;
  johndoe.height  = 180;
  johndoe.weight = 75;
  print_person(johndoe); 

  return(0);
    
}
