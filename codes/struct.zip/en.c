#include <stdio.h>

// Enum 1: Assegnazione automatica (OK=0, WARNING=1, ERROR_NOT_FOUND=2, ERROR_CRITICAL=3)
typedef enum {
    OK,
    WARNING,
    ERROR_NOT_FOUND,
    ERROR_CRITICAL
} StatoOperazione;

// Enum 2: Assegnazione esplicita dei valori
typedef enum {
    HTTP_OK = 200,
    HTTP_NOT_FOUND = 404,
    HTTP_SERVER_ERROR = 500
} CodiceHTTP;

void gestisci_stato(StatoOperazione st) {
    // Usare l'enum nello switch rende il codice parlante e auto-documentato
    switch (st) {
        case OK:
            printf("[LOG] Operazione completata con successo (valore intero: %d)\n", st);
            break;
        case WARNING:
            printf("[LOG] Attenzione: completato con avvertimenti (valore intero: %d)\n", st);
            break;
        case ERROR_NOT_FOUND:
            printf("[LOG] Errore: Risorsa non trovata (valore intero: %d)\n", st);
            break;
        case ERROR_CRITICAL:
            printf("[LOG] Errore Critico di Sistema! (valore intero: %d)\n", st);
            break;
    }
}

int main(void) {
    StatoOperazione s1 = OK;
    StatoOperazione s2 = ERROR_NOT_FOUND;
    CodiceHTTP http = HTTP_NOT_FOUND;

    printf("=== VALORI ENUM AUTOMATICI ===\n");
    gestisci_stato(s1);
    gestisci_stato(s2);

    printf("\n=== VALORI ENUM ESPLICITI ===\n");
    printf("Codice HTTP %d: Risorsa non trovata\n", http);

    return 0;
}
