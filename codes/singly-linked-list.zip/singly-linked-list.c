#include "singly-linked-list.h"

// Creazione di un nuovo nodo
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) { // Equivale a scrivere if (newNode == NULL)
        printf("Errore di allocazione memoria.\n");
        exit(1); // exit(1) ci dice che usciamo direttamente dal programma senza tornare nel main perché c'è stato un errore
		 // equivale a fare return NULL; e poi controllare nel main o nel chiamante il valore ritornato, e terminare il programma
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Stampa della lista
void printList(Node* head) {
    Node* temp = head; // head viene passato per valore quindi non sarebbe necessario usate un ptr temporaneo..
    // però se oltre a stampare dovessi fare altre operazioni perderei il riferimento alla testa se usassi head nel while.. è buona pratica usare una variabile
    // diversa per scandire le liste
    while (temp != NULL) {
        printf("%d -> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

// Liberazione della memoria della lista
void freeList(Node** head) { // sto passando head per riferimento, devo modificare effettivamente la lista!
    Node* temp =  NULL;
    while (*head != NULL) {
        temp = *head; // salva il nodo corrente da cancellare
        *head = (*head)->next; // fai avanzare head prima di liberare
        free(temp); // mai liberare head senza aver salvato head->next, perderemmo tutta la lista!
    }
}


// TENTATIVO 1: Usiamo Node* per l'inserimento in testa SBAGLIATO!
// Perché questa funzione è sbagliata?
void insertHead_val(Node* head, int data) {
    Node* newNode = createNode(data);
    newNode->next = head;
    head = newNode;
}

// TENTATIVO 2: ritorna il puntatore
// Se uso un valore di ritorno, la funzione chiamante ha la responsabilità di effettuare il collegamento della lista
// assegnando il puntatore ritornato alla testa (per l'inserimento in testa)
Node* insertHead_ret(Node* head, int data) {
    Node* newNode = createNode(data);
    newNode->next = head;
    return newNode;
    
}


/**
 * Inserisce un nuovo nodo contenente 'data' dopo un nodo specificato ('prev_node').
 * 
 * NOTA DIDATTICA SULL'USABILITÀ:
 * Questa funzione è "ibrida" e unisce due logiche distinte per comodità:
 * - Se prev_node è NULL, sfrutta head_ref per effettuare un inserimento in TSTA.
 * - Se prev_node è valido, ignora head_ref e inserisce il nodo IN MEZZO o IN CODA.
 * 
 * Sebbene funzioni, questa scelta progettuale riduce la robustezza e la pulizia 
 * dell'interfaccia: costringe chi sviluppa a ricordarsi che 'head_ref' è indispensabile 
 * solo nel primo caso, mentre negli altri casi serve un puntatore a un nodo esistente.
 */
void insertAfter(Node** head_ref, Node* prev_node, int data) {
    Node* newNode = createNode(data);
    // questa funzione è corretta ma poco robusta perché devo portarmi dietro parametri diversi 
    // ed effettuare check all'interno per capire se sto inserendo in testa o in mezzo/coda
    if (prev_node == NULL) { 
        // CASO 1: Inserimento in testa
	// qui stiamo usando effettivamente *head_ref (perché passiamo l'indirizzo?)
	newNode->next = *head_ref;
	*head_ref = newNode;
    } else {
        // CASO 2: Inserimento in mezzo o in coda
	// Modifica solo i collegamenti interni; 'head_ref' non viene toccato
        newNode->next = prev_node->next;
	prev_node->next = newNode;
    }
}




/**
 * Inserisce un nuovo nodo con il valore 'data' alla fine (in coda) della lista.
 * 
 * NOTA SULLA COMPLESSITÀ:
 * L'inserimento in coda richiede di scorrere l'intera lista partendo dalla testa 
 * fino a raggiungere l'ultimo nodo. Ha quindi una complessità temporale di O(N),
 * a differenza dell'inserimento in testa che è O(1).
 */
void insertTail(Node** head, int data) {
    Node* newNode = createNode(data);
    if (*head == NULL) { // se la lista è vuota
        *head = newNode;
        return;
    }
    Node* temp = *head; // perché uso un puntatore temporaneo?
    // Avanziamo finché il campo 'next' del nodo corrente non è NULL, 
    // il che significa che siamo arrivati esattamente all'ULTIMO nodo della lista.
    while (temp->next != NULL) { 
    	temp = temp->next;
    }
    // L'ultimo nodo attuale ora punta al nuovo nodo appena creato.
    // Il 'next' del newNode è già NULL grazie alla funzione createNode.
    temp->next = newNode;
}



// Eliminazione di un nodo in base al valore (key)
void deleteValue(Node** head, int key) {
    Node *temp = *head, *prev = NULL;

// È obbligatorio perché, in una lista semplicemente collegata, i nodi puntano solo in avanti.
// Per eliminare il primo elemento (la testa), non esiste un nodo precedente ("prev") da aggiornare;
// l'unico modo per rimuoverlo è spostare direttamente il puntatore *head sul nodo successivo 
// e liberare la memoria della vecchia testa. Senza questo controllo iniziale, il codice 
// cercherebbe di usare un puntatore "prev" non inizializzato, causando un Segmentation Fault.
    if (temp != NULL && temp->data == key) {  // se devo eliminare il primo elemento
        *head = temp->next; // Spostiamo la testa sul secondo elemento
        free(temp); // liberiamo la memoria del VECCHIO primo nodo
        return;
    }

    /* 
     * CASO GENERALE: Scorrimento della lista alla ricerca del valore.
     * Manteniamo traccia del nodo precedente (`prev`) perché, per sganciare il nodo 
     * corrente (`temp`), dovremo modificare il puntatore `next` del nodo che lo precede.
     */
    while (temp != NULL && temp->data != key) { 
        prev = temp;
	temp = temp->next;
    }

    if (temp == NULL) return; // Valore non trovato

    // SGANCIO E RIMOZIONE: Il nodo precedente salta quello da eliminare 
    // e si collega direttamente al successivo.
    prev->next = temp->next;

/**
Eliminare un nodo in C non significa solo scollegarlo dai puntatori (prev->next = temp->next), 
ma bisogna deallocare esplicitamente la memoria con free(temp), altrimenti si crea un Memory Leak.
*/
    free(temp); // libero il nodo


}




/**
 * ============================================================================
 * APPROCCIO AVANZATO: IL PUNTATORE AL PUNTATORE (Node **prec)
 * ============================================================================
 * 
 * IN COSA SI DIFFERENZIA DALLE FUNZIONI TRADIZIONALI (insertAfter / deleteValue)?
 * 
 * 1. ELIMINAZIONE DEI CASI SPECIALI (IF/ELSE):
 *    Nelle funzioni tradizionali (come `deleteValue`), eravamo costretti a gestire 
 *    separatamente la testa della lista (`*head`) rispetto ai nodi interni (`prev->next`), 
 *    perché la testa è un puntatore alla struttura "diretto", mentre i nodi interni sono acceduti
 *    attraverso i puntatori `next`.
 *    Qui invece sfruttiamo il concetto di "indirizzo del puntatore da aggiornare" (`Node **prec`), 
 *    trattando la testa e un qualsiasi puntatore `next` nello stesso identico modo.
 * 
 * 2. SEPARAZIONE DELLE RESPONSABILITÀ (SEPARATION OF CONCERNS):
 *    A differenza di `deleteValue` (che cercava il valore, scollegava il nodo e chiamava 
 *    direttamente la `free`), questa funzione di rimozione si occupa solo della logica 
 *    dei puntatori, restituendo il nodo isolato al chiamante. La gestione della memoria 
 *    (`free`) viene delegata all'esterno, rendendo la funzione molto più flessibile.
 */


/**
 * Inserimento generico con nodo pre-creato.
 * @param prec    L'indirizzo del puntatore da aggiornare. A differenza di `insertAfter` 
 *                (che distingueva tra `&head` se `prev_node` era NULL o `prev_node->next` altrimenti), 
 *                qui basta passare direttamente l'esatto indirizzo del puntatore che deve 
 *                ricevere il nuovo nodo (es. &head oppure &(node->next)).
 * @param newNode Il nuovo nodo già allocato da inserire.
 */
void insert(Node **prec, Node *newNode) {
    newNode->next = *prec; // il nuovo nodo punterà a ciò a cui puntava il nodo target (*prec)
    *prec = newNode; // il nodo target (*prec) punta al nuovo nodo (sovrascriviamo l'indirizzo puntato!)
}

/**
 * Rimozione generica che scollega e restituisce il nodo (per poter fare la free fuori).
 * @param  prec L'indirizzo del puntatore che punta al nodo da eliminare 
 *              (es. &head o &(prev->next)).
 * @return      Il nodo scollegato. A differenza di `deleteValue`, qui non viene eseguita 
 *              alcuna `free()`: spetta al chiamante decidere se deallocare il nodo o riusarlo.
 */
Node* delete_node(Node **prec) {
    
    Node *target = *prec;     // Il nodo da rimuovere
    *prec = target->next; // Scolleghiamo il nodo agganciando il puntatore direttamente al suo successore
    target->next = NULL; // Isoliamo completamente il nodo estratto per sicurezza
    
    return target;            // Restituisce il nodo al chiamante che dovrà liberarlo!
}




/**
 * Inserimento ordinato: cerca la posizione corretta scorrendo con un Node** 
 * e sfrutta la funzione insert() per completare l'operazione.
 */
void insertOrdered(Node **head, Node *newNode) {
    
    // Controllo di sicurezza iniziale (se newNode è NULL non facciamo nulla)
    if (newNode == NULL) return;

    Node **prec = head;
    
    // CICLO DI RICERCA DELLA POSIZIONE CORRETTA:
    // Dobbiamo avanzare finché non arriviamo alla fine della lista (*prec != NULL) 
    // E finché il valore contenuto nel nodo attuale è STRETTAMENTE MINORE del valore del newNode.
    // 
    // Suggerimento: Ricorda che 'prec' è un puntatore a puntatore (Node**), 
    // quindi per accedere al nodo che punta si usa *prec, e per leggerne il dato usi (*prec)->data.
    while (*prec != NULL && (*prec)->data < newNode->data) {
        prec = &((*prec)->next);
    }
    // Una volta trovato il punto di interruzione corretto, 'prec' conterrà l'indirizzo 
    // del puntatore (che sia la testa o il next del nodo precedente) in cui inserire il nodo.
    // Sfruttiamo la funzione generica 'insert' creata in precedenza!
    insert(prec, newNode);
}


/**
 * Nuova versione di deleteValue che cerca il valore e sfrutta delete_node() 
 * per scollegarlo ed effettuare la free() in sicurezza.
 * IN COSA SI DIFFERENZIA DALLA VECCHIA deleteValue?
 * 1. ZERO CASI SPECIALI (ADDIO IF SULLA TESTA):
 *    Nella vecchia versione eravamo costretti a fare un controllo separato `if (temp->data == key)` 
 *    perché rimuovere la testa richiedeva di aggiornare `*head`, mentre rimuovere un nodo in mezzo 
 *    richiedeva di aggiornare `prev->next`. Qui invece facciamo scorrere direttamente il *puntatore 
 *    al puntatore* (`Node **prec`), che punta dinamicamente o a `head` o al campo `next` del nodo precedente, 
 *    trattando la testa e gli altri nodi esattamente allo stesso modo.
 * 
 * 2. RIUTILIZZO DEL CODICE:
 *    Invece di duplicare la logica di scollegamento, questa funzione delega il compito a `delete_node()`, 
 *    concentrandosi unicamente sulla ricerca del valore e sulla successiva deallocazione della memoria.
 */
 */
void delete_value(Node** head, int key) {
    // Controllo di sicurezza iniziale: se la lista non esiste o è vuota, usciamo subito.
    if (head == NULL || *head == NULL) return;

    Node **prec = head;

    // Cerca il puntatore al nodo contenente la chiave
    while (*prec != NULL && (*prec)->data != key) {
        // Facciamo avanzare 'prec' salvando l'indirizzo del campo 'next' del nodo corrente.
        // Camminiamo sugli "indirizzi dei collegamenti" 
        // anziché sui nodi stessi!
	prec = &((*prec)->next);
    }

    // Se il nodo è stato trovato (*prec non è NULL)
    if (*prec != NULL) {
        Node *removed = delete_node(prec); // Scollega il nodo
        if (removed != NULL) {
            free(removed); // Dealloca la memoria direttamente nella funzione!
        }
    }
}



// Restituisce 1 se l'elemento è presente nella lista, 0 altrimenti
int search(Node* head, int v) {
    Node* current = head;
    
    while (current != NULL) {
        if (current->data == v) {
            return 1; // Trovato!
        }
        current = current->next; // Passa al nodo successivo
    }
    
    return 0; // Elemento non trovato
}


// Restituisce il numero di nodi presenti nella lista
int length(Node* head) {
    int count = 0;
    Node* current = head;
    
    while (current != NULL) {
        count++;
        current = current->next;
    }
    
    return count;
}


/* Esercizio 3: reverse della lista in place */

/**
 * Inverti i puntatori next della lista in-place (senza creare nuovi nodi).
 * Modifica direttamente la testa tramite doppio puntatore (Node**).
 */
void reverse(Node** head) {
    if (head == NULL || *head == NULL) {
        return; // Lista vuota o puntatore non valido, nulla da invertire
    }

    Node* prev = NULL; // terrà traccia del nodo precedente (è NULL perché la "vecchia" head diventerà l'ultimo nodo)
    Node* current = *head; // nodo corrente che stiamo esaminando e scorrerà la lista
    Node* next = NULL; // puntatore temporaneo per salvarci il riferimento al nodo successivo prima di modificare la lista

    while (current != NULL) {
        // Salviamo il riferimento al nodo successivo
        // altrimenti perderai il contatto con il resto della lista quando invertirai il puntatore!
        // Suggerimento: guarda il campo next di current...
        next = current->next;
        
        // Invertiamo il puntatore: ora il nodo corrente punta al precedente
        current->next = prev;
        
        // Facciamo avanzare prev e current 
        // Suggerimento: 'prev' diventa il current, e 'current' diventa il next che avevi salvato al punto 1.
        prev = current;
        current = next;
    }

    // Il ciclo è finito, a quale nodo punta 'prev' adesso? 
    // Ricordati che devi aggiornare la testa della lista (*head) passata come parametro!
    *head = prev;
    
}
