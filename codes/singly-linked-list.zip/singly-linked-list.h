#ifndef LIST_H
#define LIST_H

#include <stdio.h>
#include <stdlib.h>

// Definizione della struttura del nodo
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Prototipi delle funzioni
Node* createNode(int data);
void printList(Node* head);
void freeList(Node** head);
void insertHead(Node** head, int data);
void insertHead_val(Node* head, int data);
Node* insertHead_ret(Node* head, int data);
void insertAfter(Node** head_ref, Node* prev_node, int data);
void insertTail(Node** head, int data);
void deleteValue(Node** head, int key);


// NUOVE FUNZIONI (con nodo pre-creato e puntatore a puntatore generico)
void insert(Node **prec, Node *newNode);
Node* delete_node(Node **prec);


/**
Esercizio: implementa la funzione insertOrdered
*/
void insertOrdered(Node **head, Node *newNode);
void delete_value(Node** head, int key); // Nuova versione basata su delete_node


int search(Node* head, int v);
int length(Node* head);

/* Esercizio: implementa la funzione che inverte una lista, senza usare memoria di appoggio extra*/
void reverse(Node** head);

#endif // LIST_H
