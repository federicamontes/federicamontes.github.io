#ifndef STACK_H
#define STACK_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definizione del nodo dello Stack (struttura identica a un nodo di lista singola)
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

// Prototipi delle operazioni sullo Stack
StackNode* createStackNode(int data);
bool isEmpty(StackNode* top);
void push(StackNode** top, int data);
int pop(StackNode** top);
int peek(StackNode* top); //questo metodo viene anche chiamato top() a volte
void freeStack(StackNode** top);

#endif // STACK_H
