#include "stack.h"

// Creazione di un nuovo nodo per lo stack
StackNode* createStackNode(int data) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    if (!newNode) {
        printf("Errore di allocazione memoria.\n");
        exit(1);
    }
    newNode->data = data;
    newNode->next = NULL;
    return newNode;
}

// Verifica se lo stack è vuoto
bool isEmpty(StackNode* top) {
    return top == NULL; // stack vuoto vuol dire che punta a NULL
}

// PUSH: Inserimento in cima (coincide esattamente con l'inserimento in testa!)
void push(StackNode** top, int data) {
    StackNode* newNode = createStackNode(data);
    newNode->next = *top;
    *top = newNode; // La testa della lista diventa il nuovo top dello stack
}

// POP: Rimozione dalla cima (coincide con la rimozione della testa)
// come cambierebbe la funzione se volessi ritornare l'elemento rimosso invece del valore memorizzato?
int pop(StackNode** top) {
    // check: se lo stack è vuoto, la pop() ritorna -1 
    if (isEmpty(*top)) {
        printf("Errore: Lo stack è vuoto\n");
        return -1; // Valore di errore
    }

    StackNode* temp = *top;
    int poppedData = temp->data; // mi chiede di ritornare il valore, intanto me lo salvo
    
    *top = (*top)->next; // Sposta il top sul nodo successivo
    // eventualmente isolare (*top)->next...
    free(temp);          // Dealloca il vecchio nodo in cima
    
    return poppedData;
}

// PEEK (o top): Legge il valore in cima senza rimuoverlo
int peek(StackNode* top) {
    if (isEmpty(top)) {
        printf("Errore: Lo stack e' vuoto.\n");
        return -1;
    }
    return top->data;
}

// Svuota completamente lo stack liberando la memoria
void freeStack(StackNode** top) {
    while (!isEmpty(*top)) {
        pop(top); // pop ritorna l'elemento rimosso, qui non lo stiamo usando
    }
}
