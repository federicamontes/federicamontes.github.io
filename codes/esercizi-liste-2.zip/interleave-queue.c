#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definizione del nodo per le strutture collegate
typedef struct Node {
    int data;
    struct Node* next;
} Node;

// Definizione della Coda (Queue)
typedef struct {
    Node* front;
    Node* rear;
} Queue;

// Operazioni di base della Coda
void initQueue(Queue* q) {
    q->front = q->rear = NULL;
}

bool isQueueEmpty(Queue* q) {
    return q->front == NULL;
}

void enqueue(Queue* q, int value) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    newNode->data = value;
    newNode->next = NULL;
    if (q->rear == NULL) {
        q->front = q->rear = newNode;
        return;
    }
    q->rear->next = newNode;
    q->rear = newNode;
}

int dequeue(Queue* q) {
    if (isQueueEmpty(q)) return -1;
    Node* temp = q->front;
    int val = temp->data;
    q->front = q->front->next;
    if (q->front == NULL) {
        q->rear = NULL;
    }
    free(temp);
    return val;
}

/**
 * Riorganizza la coda effettuando l'interleaving tramite due code ausiliarie.
 * 
 * Complessità Temporale: O(N)
 * Complessità Spaziale: O(N) per le due code ausiliarie
 */
void interleaveQueueTwoQueues(Queue* q) {
    // Calcoliamo la dimensione totale della coda
    int n = 0;
    Node* curr = q->front;
    while (curr != NULL) {
        n++;
        curr = curr->next;
    }

    if (n % 2 != 0 || n == 0) return; // La traccia richiede dimensione pari

    int halfSize = n / 2;

    // Inizializziamo le due code ausiliarie
    Queue firstHalf, secondHalf;
    initQueue(&firstHalf);
    initQueue(&secondHalf);

    // Spostiamo la prima metà degli elementi nella coda 'firstHalf'
    for (int i = 0; i < halfSize; i++) {
        enqueue(&firstHalf, dequeue(q));
    }

    // Spostiamo la seconda metà degli elementi nella coda 'secondHalf'
    for (int i = 0; i < halfSize; i++) {
        enqueue(&secondHalf, dequeue(q));
    }

    // Fondiamo le due metà alternando gli elementi e reinserendoli in 'q'
    while (!isQueueEmpty(&firstHalf) && !isQueueEmpty(&secondHalf)) {
        enqueue(q, dequeue(&firstHalf));
        enqueue(q, dequeue(&secondHalf));
    }
}


void printQueue(Queue* q) {
    Node* curr = q->front;
    while (curr != NULL) {
        printf("%d ", curr->data);
        curr = curr->next;
    }
    printf("\n");
}

int main() {
    printf("=== TEST: Queue Interleaving con Due Code Ausiliarie ===\n\n");

    Queue q;
    initQueue(&q);

    // Test con [2, 4, 3, 1]
    int arr[] = {2, 4, 3, 1};
    int size = sizeof(arr) / sizeof(arr[0]);

    for (int i = 0; i < size; i++) {
        enqueue(&q, arr[i]);
    }

    printf("Coda iniziale: ");
    printQueue(&q);

    interleaveQueueTwoQueues(&q);

    printf("Coda dopo l'interleaving (atteso: 2 3 4 1): ");
    printQueue(&q);

    return 0;
}
