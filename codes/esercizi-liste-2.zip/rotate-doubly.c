#include <stdio.h>
#include <stdlib.h>
#include "../../doubly/doubly-list.h"

/**
 * Ruota una lista doppiamente collegata in senso antiorario di 'p' nodi.
 * Modifica i puntatori in-place e restituisce la nuova testa della lista.
 * 
 * Strategia:
 * 1. Se p == 0 o la lista è vuota/ha un solo nodo, la rotazione non è necessaria.
 * 2. Troviamo l'ennesimo nodo (dopo 'p' passaggi) che diventerà il nuovo ultimo nodo,
 *    e il suo successivo che diventerà la nuova testa (`newHead`).
 * 3. Sganciamo la catena: 
 *    - Il nuovo ultimo nodo (`newTail->next`) viene impostato a NULL.
 *    - La vecchia testa (`head`) viene collegata alla coda precedente.
 *    - La nuova testa (`newHead->prev`) viene impostata a NULL.
 * 
 * Complessità Temporale (Worst-Case): O(p), dove p è il numero di rotazioni, 
 *                          che è comunque limitato dal numero totale di nodi N -> O(N).
 * Complessità Spaziale: O(1), poiché modifichiamo i puntatori "in-place".
 */
Node* rotateDoublyLeft(Node* head, int p) {
    if (head == NULL || p <= 0) {
        return head;
    }

    Node* current = head;
    int count = 1;

    // Avanziamo fino al p-esimo nodo (che sarà il nuovo ultimo nodo)
    while (count < p && current != NULL) {
        current = current->next;
        count++;
    }

    // Dobbiamo capire quale condizione del while è scattaa: se p è maggiore o uguale al numero di nodi, non ruotiamo
    if (current == NULL || current->next == NULL) {
        return head;
    }

    // mi salvo i puntatori che mi servono: la nuova coda e la nuova testa a valle dello shift che devo effettuare
    // la vecchia testa ce l'ho già ed è puntata da head
    Node* newTail = current;
    Node* newHead = current->next;

    // Troviamo l'ultimo nodo della lista originale
    Node* tail = newHead;
    while (tail->next != NULL) {
        tail = tail->next;
    }

    // Ricolleghiamo i puntatori per eseguire la rotazione
    // Il vecchio ultimo nodo punta alla vecchia testa
    tail->next = head;
    head->prev = tail;

    // Spezziamo la lista tra il nuovo ultimo nodo e la nuova testa
    newTail->next = NULL;
    newHead->prev = NULL;

    return newHead;
}
