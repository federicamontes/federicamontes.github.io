#include <stdio.h>

/**
IN questa variante del celebrity problem usiamo direttamente la matrice in input, per mantenere uno spazio O(1)
anziché spazio O(N) dovuto all'uso dello stack ausiliario.
Si sfruttano le stesse condizioni di celebrità per scartare "candidate", ma anziché
fare push e pop dallo stack semplicemente si cambia il valore di "candidate" usando l'indice di colonna i
che ha verificato con successo la condizione mat[candidate][i] == 1 per accedere alla riga numero i
e ricominciare la valutazione.
Alla fine rimane un solo valore di "candidate" da verificare.
*/

int findCelebrity(int** mat, int n) {
    if (n <= 0) return -1;

    int candidate = 0; // Partiamo ipotizzando che la persona 0 sia la celebrità

    // FASE 1 & 2: Ricerca del candidato in un unico passaggio O(N)
    for (int i = 1; i < n; i++) {
        if (mat[candidate][i] == 1) {
            // Il candidato conosce 'i' -> Il candidato è squalificato. 
            // La persona 'i' diventa il nuovo potenziale candidato.
            candidate = i;
        }
        // Se mat[candidate][i] == 0, 'i' non può essere la celebrità, 
        // quindi 'candidate' resta lo stesso e andiamo avanti.
    }

    // FASE 3: Validazione finale del candidato superstite
    // Verifichiamo rigorosamente che non conosca nessuno e che tutti lo conoscano
    for (int i = 0; i < n; i++) {
        if (i != candidate) {
            if (mat[candidate][i] == 1 || mat[i][candidate] == 0) {
                return -1; // Validazione fallita: nessuna celebrità
            }
        }
    }

    return candidate; // Trovato!
}
