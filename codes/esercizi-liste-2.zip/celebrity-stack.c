#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

// Definizione del nodo dello Stack per interi (indici delle persone)
typedef struct StackNode {
    int data;
    struct StackNode* next;
} StackNode;

// Operazioni di supporto per lo Stack
bool isStackEmpty(StackNode* top) {
    return top == NULL;
}

void push(StackNode** top, int data) {
    StackNode* newNode = (StackNode*)malloc(sizeof(StackNode));
    if (!newNode) {
        fprintf(stderr, "Errore di allocazione memoria!\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->next = *top;
    *top = newNode;
}

int pop(StackNode** top) {
    if (isStackEmpty(*top)) {
        fprintf(stderr, "Stack Underflow!\n");
        exit(EXIT_FAILURE);
    }
    StackNode* temp = *top;
    int poppedData = temp->data;
    *top = (*top)->next;
    free(temp);
    return poppedData;
}

/**
 * Risolve il problema della celebrità utilizzando uno Stack a liste collegate.
 * 
 * Complessità Temporale: O(N), poiché ogni persona viene inserita ed estratta dallo stack 
 *                          e successivamente validata in un ciclo lineare.
 * Complessità Spaziale: O(N), per memorizzare gli indici nello stack.
 */
int findCelebrity(int** mat, int n) {
    StackNode* top = NULL;

    // Inseriamo tutti i partecipanti (da 0 a n-1) nello stack
    for (int i = 0; i < n; i++) {
        push(&top, i);
    }

    // Riduciamo i candidati estraendo a coppie dallo stack
    while (top != NULL && top->next != NULL) {
        int a = pop(&top);
        int b = pop(&top);

        // Se 'a' conosce 'b', allora 'a' non può essere una celebrità. Teniamo 'b'.
        if (mat[a][b] == 1) {
            push(&top, b);
        } 
        // Altrimenti, 'b' non può essere una celebrità. Teniamo 'a'.
        else {
            push(&top, a);
        }
    }

    // Se lo stack è vuoto, non c'è alcun candidato
    if (isStackEmpty(top)) {
        return -1;
    }

    // Rimane un unico candidato finale
    int candidate = pop(&top);

    // Fase di validazione del candidato
    for (int i = 0; i < n; i++) {
        if (i != candidate) {
            // Il candidato non deve conoscere nessuno (mat[candidate][i] deve essere 0)
            // Tutti devono conoscere il candidato (mat[i][candidate] deve essere 1)
            if (mat[candidate][i] == 1 || mat[i][candidate] == 0) {
                return -1; // Candidato non valido
            }
        }
    }

    return candidate;
}
