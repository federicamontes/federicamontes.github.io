'/**
 * Rileva ed elimina un eventuale ciclo in una lista semplicemente collegata.
 * Utilizza l'algoritmo di Floyd (Cycle Detection & Removal).
 * Se l'algoritmo non si conosce è impossibile risolvere questo esercizio in 2 ore, quindi viene mostrato solo per scopo didattico
 *
 * Complessità Temporale (Worst-Case): O(N), dove N è il numero di nodi della lista.
 * Complessità Spaziale (Worst-Case): O(1), poichè opera in-place con puntatori di supporto.
 */
void detectAndRemoveLoop(Node* head) {
    if (head == NULL || head->next == NULL) {
        return; // Lista vuota o con 1 solo nodo privo di cicli
    }

    Node* slow = head;
    Node* fast = head;

    // FASE 1: Rilevazione del ciclo tramite puntatori slow e fast
    while (fast != NULL && fast->next != NULL) {
        slow = slow->next;
        fast = fast->next->next;

        // Se slow e fast si incontrano, il ciclo esiste!
        if (slow == fast) {
            break;
        }
    }

    // Se fast o fast->next sono NULL, la lista è lineare (nessun ciclo)
    if (fast == NULL || fast->next == NULL) {
        return;
    }

    // FASE 2: Individuazione del nodo di inizio del ciclo e rimozione
    slow = head;

    // Caso speciale: il ciclo parte proprio dalla head della lista
    if (slow == fast) {
        while (fast->next != slow) {
            fast = fast->next;
        }
        fast->next = NULL; // Interrompiamo il ciclo
        return;
    }

    // Caso generale: avanziamo entrambi i puntatori di 1 passo alla volta:
    // Non è banale dimostrare che questo funzioni!
    while (slow->next != fast->next) {
        slow = slow->next;
        fast = fast->next;
    }

    // A questo punto fast->next (e slow->next) puntano al primo nodo del ciclo.
    // 'fast' si trova sul nodo di coda del ciclo: spezziamo il collegamento circolare!
    fast->next = NULL;
}
