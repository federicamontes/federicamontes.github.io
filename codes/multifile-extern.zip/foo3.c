#include <stdio.h>
#include <math.h>
#include "foobar3.h"

int my_variable=1;

int main(int argc, char **argv)
{
  int times, i=10;

  printf("Init: i=%d times=%d  \n",i,times);
  printf("Before  foobar: i=%d my_variable=%d  \n",i,my_variable);
  foobar(i);
  printf("After foobar: i=%d my_variable=%d  \n",i,my_variable);
  

  return 0;
}
