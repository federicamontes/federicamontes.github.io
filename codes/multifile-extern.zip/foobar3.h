#ifndef FOOBAR3_H_
#define FOOBAR3_H_

extern int my_variable;

void foobar(int k);

#endif
