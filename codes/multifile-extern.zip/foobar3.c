#include "foobar3.h"


void foobar(int k)
{
  my_variable += k;
}
