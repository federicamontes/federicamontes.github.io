#include <stdio.h>

int main(void) {

	int i = 1;
	double result;
	result = ((double)i/2)*2;

	printf("Result is: %f\n",result);
	return 0;
}
