#include <stdio.h>
#include <math.h>
#include <stdint.h>

int main(int argc, char **argv)
{
  int  p ,q, k, l;
  p = -12;
  q = 15;

  k = q >> 2; // k = q / 2^2
  l = p >> 2; // l = p / 2^2

  p <<= 3; // p = p * 2^3
  printf("  Q: %d   K %d  P %d  L %d \n",q,k,p,l);

  q &= 0x0d;
  printf("  Q: %d   K %d  P %d  L %d \n",q,k,p,l);
  return(0);
}
