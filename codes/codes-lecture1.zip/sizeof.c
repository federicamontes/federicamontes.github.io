#include <stdio.h>

int main() {
    int a;
    unsigned int b;
    long long c;

    printf("int: %lu Byte\n", sizeof(a));
    printf("unsigned: %lu Byte\n", sizeof(b));
    printf("long long: %lu Byte\n", sizeof(c));

    return 0;
}
