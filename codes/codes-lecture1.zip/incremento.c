#include <stdio.h>

int main(void) {

	int i;
	i = 0;
	printf("Stampo i: %d \n", i++);
	printf("Il valore di i è: %d \n", i);
	i = 0;
	printf("Azzeramento di i %d \n", i);
	
	printf("Stampo i: %d \n", ++i);


	return 0;
}
