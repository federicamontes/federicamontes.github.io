#include <stdio.h>

int main (void) {

	int i = 0;
	int sum = 0;
	for (i; i < 255; ++i) {
		printf("Indice i: %d\n ", i);
		sum += i;
	}

	printf("La somma è: %d \n", sum);


	return 0;
}
