#ifndef QUEUE_H
#define QUEUE_H

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>

/**
Se strutturassi in questo modo:
struct QNode {
   int data;
   struct QNode *next;
   struct QNode *front; // ? Ha senso?
   struct QNode *tail;  // ? Ha senso?
};

Avrei ridondanza, perché ogni singolo nodo della coda si porterebbe dietro tail e front di tutta la coda.
Inoltre ogni volta che fai un enqueue o un dequeue, la tail o la front cambiano. Dovresti aggiornare quei puntatori in tutti i nodi della lista affinché siano coerenti

Quindi dobbiamo suddividere quelle che sono informazioni della coda (front, tail) e informazioni del nodo della coda (campo data, campo next)

Quindi l'alternativa è definire solo la struct QNode come sotto, e poi nel main dichiarare
QNode* front = NULL;
QNode* tail = NULL;

come due puntatori separatamente.
A questo punto cambiano le firme delle funzioni:
- void enqueue(QNode **front_ref, QNode **tail_ref, int value);
- int dequeue(QNode **front_ref, QNode **tail_ref);


*/


// Nodo della coda
typedef struct QNode {
    int data;
    struct QNode* next;
} QNode;

// Struttura di controllo della Coda con i campi front e tail
typedef struct Queue {
    QNode* front;
    QNode* tail;
} Queue;

// Prototipi delle operazioni
Queue* createQueue();
bool isEmpty(Queue* q);
void enqueue(Queue* q, int value);
int dequeue(Queue* q);
int first(Queue* q);
void freeQueue(Queue* q);

#endif // QUEUE_H
