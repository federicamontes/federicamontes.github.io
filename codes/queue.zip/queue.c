#include "queue.h"

// Creazione e inizializzazione di una nuova coda vuota
// qui sto usando una doppia struct per robustezza e trasparenza
// creo una struct Queue che contiene come campi dei QNode, 
// QNode è a  propria volta una struct che contiene un campo intero data e un puntatore a QNode, come per la lista collegata
Queue* createQueue() {
    Queue* q = (Queue*)malloc(sizeof(Queue));
    if (!q) {
        printf("Errore di allocazione memoria.\n");
        exit(1);
    }
    q->front = NULL;
    q->tail = NULL;
    return q;
}

// Verifica se la coda è vuota
bool isEmpty(Queue* q) {
    return q->front == NULL;
}

// ENQUEUE: Inserimento in fondo alla coda (tail)
// Perché mi basta passare Queue * e non un doppio puntatore? Perché all'interno di Queue ho altri puntatori
// e modifico i campi interni, non q!
void enqueue(Queue* q, int value) {
    // per modularità potrei fare una funzione QNode *createQNode(int value) che inizia qui -
    QNode* newNode = (QNode*)malloc(sizeof(QNode));
    if (!newNode) {
        printf("Errore di allocazione memoria.\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = value;
    newNode->next = NULL;
    //--- e finisce qui

    // Caso speciale: se la coda è vuota, front e tail coincidono sul nuovo nodo
    if (q->tail == NULL) {
	// assegnamento multiplo, è equivalente scrivere due righe separate con il singolo assegnamento a newNode
        q->front = q->tail = newNode; // coda con un solo elemento: front e tail puntano allo stesso nodo
        return;
    }

    // Altrimenti, attacchiamo il nuovo nodo in fondo e aggiorniamo la tail
    q->tail->next = newNode;  // attacco il nuovo nodo in coda
    q->tail = newNode; // modifico il puntatore tail alla nuova tail (perché sto usando Queue *q)

    //Cosa succederebbe se avessimo solo front e non tail? Come dovrei inserire in tail?
}

// DEQUEUE: Rimozione dall'inizio della coda (front)
int dequeue(Queue* q) {

    if (isEmpty(q)) {
        printf("Errore: Coda vuota!\n");
        return -1; // Valore di errore
    }

    QNode* temp = q->front;
    int data = temp->data;

    q->front = q->front->next; // Spostiamo front sul secondo elemento

    // Se dopo la rimozione la coda diventa vuota, dobbiamo azzerare anche tail!
    if (q->front == NULL) {
        q->tail = NULL;
    }

    free(temp);
    return data;
}

// FIRST: Legge il primo elemento in testa senza rimuoverlo
int first(Queue* q) {
    if (isEmpty(q)) {
        printf("Errore: La coda e' vuota.\n");
        return -1;
    }
    return q->front->data; //quando accedo usando la Queue *q devo accedere al puntatore a QNode, in questo caso front perché mi chiede il primo elemento
}

// Svuota e dealloca l'intera coda
void freeQueue(Queue* q) {
    while (!isEmpty(q)) {
        dequeue(q);
    }
    free(q);
}
