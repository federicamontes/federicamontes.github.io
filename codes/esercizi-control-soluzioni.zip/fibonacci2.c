#include <stdio.h>

/**
2. Scrivi un programma C che prenda in input un intero N e calcoli i primi N termini della serie di Fibonacci. Stampali in sequenza.
*/

int main(void) {
    int n;

    printf("Quanti termini della serie di Fibonacci vuoi stampare? ");
    /* 
     * CONTROLLO DI ROBUSTEZZA:
     * Verifichiamo che l'input sia un intero valido e che sia strettamente maggiore di 0.
     * Chiedere 0 o un numero negativo di termini non ha senso in questo contesto.
     */
    if (scanf("%d", &n) != 1 || n <= 0) {
        printf("Errore: inserisci un intero maggiore di 0.\n");
        return 1;
    }

    printf("I primi %d termini della serie di Fibonacci sono:\n", n);

    // Gestione dei primi due termini speciali
    if (n >= 1) {
        printf("0");
    }
    if (n >= 2) {
        printf(", 1");
    }

    // Variabili per il calcolo iterativo
    long long a = 0; // F(i-2)
    long long b = 1; // F(i-1)
    long long corrente = 0;

    // Stampa dei termini successivi dal terzo in poi (indice 2)
    /* 
     * CICLO DI GENERAZIONE (dal 3° termine in poi, cioè i = 3 fino ad n):
     * Se l'utente ha chiesto meno di 3 termini (es. n=1 o n=2), il ciclo for 
     * viene semplicemente saltato senza causare errori, grazie ai controlli precedenti.
     */
    for (int i = 3; i <= n; i++) {
        corrente = a + b; // calcolo del nuovo termine
        printf(", %lld", corrente); 
	// occhio all'ordine di aggiornamento, perché?
        a = b; // aggiornamento variabili
        b = corrente;
    }

    printf("\n");
    return 0;
}
