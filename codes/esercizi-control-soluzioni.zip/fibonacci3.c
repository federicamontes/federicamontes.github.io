#include <stdio.h>
#include <stdbool.h>

/**
3. Scrivi un programma C che prenda in input un intero N e verifichi se quel numero appartiene alla serie di Fibonacci. Ritorna true se appartiene, false altrimenti.
Hint: ci sono due modi per effettuare questa verifica. Uno ha complessità O(N), uno ha complessità O(1). Puoi decidere di implementare quello che vuoi, a patto di saper spiegare
differenze, eventuali assunzioni, eventuali casi limite.
*/



/**
 * Funzione che verifica l'appartenenza di un numero alla serie di Fibonacci (Approccio Iterativo - O(N)).
 * Perché è O(N)? La risposta è nelle iterazioni compiute dal ciclo while. Arriviamoci con un altro esempio: se io vi chiedessi di scrivere una funzione
 * che prenda in input un intero N e mi ritorni true se è un quadrato perfetto. In quel caso non faccio N iterazioni, ma mi fermerò a "radice di N" iterazioni. Quindi
 * ad esempio se N = 100, non provo tutti i numeri da 0 a 100 per verificare se è un quadrato perfetto, ma farò 10 (radice di 100) iterazioni.
 * In questo caso il ciclo avanza sui numeri di Fibonacci, ma siccome la serie cresce in modo esponenziale, le iterazioni per giungere a target
 * saranno ancora più basse. Il numero di iterazioni è proporzionale al numero di cifre del numero (crescita logaritmica rispetto al valore).
 * 
 * E l'approccio O(1)? esiste una formula matematica chiusa per verificare se un numero x fa parte di Fibonacci: Un numero x è di Fibonacci 
 * se e solo se 5x^2 + 4 oppure 5x^2 - 4 è un quadrato perfetto. Ci sono due problemi relativi ai tipi di dato con questo approccio, sai dire quali sono?
 * Hint: uno riguarda la rappresentazione dei valori interi/long; l'altro riguarda i floating point.
 *
 * NOTA DIDATTICA SULL'ALGORITMO:
 * Invece di partire da un numero N e calcolarne l'indice (più complesso), 
 * generiamo i numeri di Fibonacci in avanti partendo da 0 e 1, 
 * fermandoci non appena superiamo o eguagliamo il valore cercato ('target').
 */
bool appartiene_a_fibonacci(long long target) {
    // check numeri negativi
    if (target < 0) {
        return false;
    }
    // 0 e 1 appartengono per definizione alla serie
    if (target == 0 || target == 1) {
        return true;
    }

    long long a = 0;
    long long b = 1;
    long long corrente = a + b;

    // Genera i numeri di Fibonacci finché non superano o raggiungono il target
    while (corrente < target) {
        a = b;
        b = corrente;
        corrente = a + b;
    }

    // Se usciamo dal ciclo perché 'corrente == target', allora il numero fa parte della serie.
    // Se 'corrente > target', significa che lo abbiamo superato senza trovarlo -> false.
    return (corrente == target);
}

int main(void) {
    long long numero;

    printf("Inserisci un numero intero da verificare: ");
    if (scanf("%lld", &numero) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    if (appartiene_a_fibonacci(numero)) {
        printf("Il numero %lld APPARTIENE alla serie di Fibonacci.\n", numero);
    } else {
        printf("Il numero %lld NON appartiene alla serie di Fibonacci.\n", numero);
    }

    return 0;
}
