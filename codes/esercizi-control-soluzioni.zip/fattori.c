/* 8. Scrivi un programma in C che calcoli e stampi tutti i fattori primi di un numero intero n preso in input. Ad esempio, se il numero è 36, l'output dovrebbe essere: 2, 2, 3, 3.
*/


// MANCA IL MAIN! Aggiungerlo se volete testare la funzione

/**
 * Funzione che calcola e stampa tutti i fattori primi di un numero.
 * 
 * NOTA:
 * 1. Perché il divisore parte da 2? Perché 1 non è un numero primo.
 * 2. Perché non incrementiamo 'divisore' quando troviamo un fattore (n % divisore == 0)?
 *    Perché un numero può avere fattori primi ripetuti (es. 36 = 2 * 2 * 3 * 3). 
 *    Lasciando lo stesso divisore, lo testiamo di nuovo finché 'n' è divisibile per esso.
 * 3. E i numeri come 4, 6, 9? Ci daranno problemi nelle iterazioni successive?
 *    No! Quando arriviamo a testare il 4, tutti i 2 possibili sono già stati "eliminati" 
 *    precedentemente. Quindi 4 non dividerà mai 'n'. Di conseguenza, il programma 
 *    testerà solo fattori che sono effettivamente primi, pur senza un test di primalità esplicito!
 */
void stampa_fattori_primi(long long n) {
    if (n <= 1) {
        printf("Nessun fattore primo per %lld\n", n);
        return;
    }

    printf("Fattori primi di %lld: ", n);
    long long divisore = 2;
    int primo = 1; // Flag per la formattazione della virgola, solo estetico assolutamente non rilevante ai fini della soluzione

    // Continuiamo a dividere finché 'n' non si riduce a 1
    while (n > 1) { // fondamentale capire come funziona questo ciclo: quando si interrompe? com'è un'esecuzione dato n?
        if (n % divisore == 0) {
            if (!primo) { // Se non è il primo fattore che stampiamo, mettiamo la virgola prima..
                printf(", ");
            }
            printf("%lld", divisore);
            n /= divisore; // Riduciamo il numero dividendolo per il fattore trovato
            primo = 0; // Da questo momento in poi sappiamo di aver già stampato almeno un numero
        } else {
	    // se non divide n passiamo al successivo
            divisore++;
        }
    }
    printf("\n");
}
