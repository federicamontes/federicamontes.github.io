#include <stdio.h>

/**
7. Crea un programma C che permetta di convertire una misura inserita dall'utente.
L'utente sceglie il tipo di conversione tramite un numero intero:
(1):Da Celsius a Fahrenheit (F = C x 9/5 + 32)
(2):Da Chilometri a Miglia (Miglia = Km x 0.621371)
(3):Da Chilogrammi a Libbre (Libbre = Kg x 2.20462)
*/

int main(void) {
    int scelta;
    double valore, risultato;

    printf("--- CONVERTITORE DI UNITA' ---\n");
    printf("1. Celsius -> Fahrenheit\n");
    printf("2. Chilometri -> Miglia\n");
    printf("3. Chilogrammi -> Libbre\n");
    printf("Seleziona la conversione (1-3): ");
    
    // Controllo di robustezza sulla scelta 
    if (scanf("%d", &scelta) != 1) {
        printf("Scelta non valida.\n");
        return 1;
    }

    // Controllo di robustezza sul valore numerico inserito (notare lo specificatore %lf per i double in scanf)
    printf("Inserisci il valore da convertire: ");
    if (scanf("%lf", &valore) != 1) {
        printf("Valore non valido.\n");
        return 1;
    }

    /*
     * COSTRUTTO SWITCH-CASE:
     * Valuta la variabile 'scelta' e salta direttamente al 'case' corrispondente.
     */
    switch (scelta) {
        case 1:
            // attenzione alla divisione intera! è vero che il programma all'esame non è compilabile, ma questo è un errore grave per quanto riguarda il casting
	    risultato = (valore * 9.0 / 5.0) + 32.0;
            printf("%.2f Celsius corrispondono a %.2f Fahrenheit.\n", valore, risultato);
            break; // attenzione al break, ometterlo è un errore grave per la sintassi e semantica del costrutto 
        case 2:
            risultato = valore * 0.621371;
            printf("%.2f Km corrispondono a %.2f Miglia.\n", valore, risultato);
            break;
        case 3:
            risultato = valore * 2.20462;
            printf("%.2f Kg corrispondono a %.2f Libbre.\n", valore, risultato);
            break;
        default: // non è obbligatorio ma non metterlo è comunque un errore di progettazione, meno grave ma sempre errore
            printf("Errore: Opzione di conversione inesistente.\n");
            break;
    }

    return 0;
}
