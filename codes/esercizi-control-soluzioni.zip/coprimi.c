#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h> // per la funzione llabs()

/* 4. Scrivi un programma C che, dati due numeri interi positivi a e b, verifichi se a e b sono co-primi. Ritorna true se sono co-primi, false altrimenti.
*/


/**
 * Funzione che calcola il Massimo Comun Divisore (MCD) usando l'Algoritmo di Euclide.
 * 
 * NOTA DIDATTICA SULLA COMPLESSITÀ:
 * Invece di testare tutti i numeri da 1 al minore tra a e b (forza bruta O(min(a,b))), 
 * l'algoritmo di Euclide sfrutta il resto della divisione intera (%) ed ha una 
 * complessità logaritmica O(log(min(a, b))), risultando incredibilmente veloce anche per numeri enormi.
 * Se richiesto di calcolare il MCD, usare un algoritmo lineare anziché logaritmico costituisce un errore.
 *
 */
long long calcola_mcd(long long a, long long b) {
    // Gestione dei valori negativi rendendoli positivi
    // in alternativa potrei avere un controllo: SE a O b è negativo, ritorna un valore considerato come errore
    a = llabs(a);
    b = llabs(b);

    // algoritmo di euclide iterativo
    while (b != 0) {
        long long temp = b;
        b = a % b;
        a = temp;
    }
    return a;
}

// Funzione che verifica se due numeri sono coprimi
bool sono_coprimi(long long a, long long b) {
    return calcola_mcd(a, b) == 1;
}

int main(void) {
    long long num1, num2;

    printf("Inserisci il primo numero intero: ");
    if (scanf("%lld", &num1) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    printf("Inserisci il secondo numero intero: ");
    if (scanf("%lld", &num2) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    if (sono_coprimi(num1, num2)) {
        printf("I numeri %lld e %lld SONO coprimi (il loro MCD e' 1).\n", num1, num2);
    } else {
        printf("I numeri %lld e %lld NON sono coprimi (il loro MCD e' diverso da 1).\n", num1, num2);
    }

    return 0;
}
