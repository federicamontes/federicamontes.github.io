#include <stdio.h>
#include <stdbool.h>

/* 5. Scrivi un programma C che dati due numeri a e b stampi tutti i numeri primi compresi tra a e b.
*/

/**
 * Funzione ottimizzata per verificare se un numero è primo.
 * 
 * NOTA DIDATTICA SULL'EFFICIENZA:
 * 1. Perché fermarsi a radice quadrata di n (i * i <= n)? 
 *    Se un numero n ha un divisore maggiore della sua radice quadrata, 
 *    deve necessariamente averne uno anche minore. Questo riduce la complessità 
 *    da O(N) a O(sqrt(N)).
 * 2. I filtri iniziali (esclusione di numeri <= 1, pari e multipli di 3) 
 *    e l'incremento di 6 nel ciclo (passo 6k ± 1) sono ottimizzazioni avanzate non obbligatorie
 *    che scartano subito la maggior parte dei numeri non primi.
 */
bool is_prime(long long n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    // Controlla i fattori fino alla radice quadrata di n (ottimizzato con passo 6)
    for (long long i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    }
    return true;
}


/**
 * Versione "Naive" (Forza Bruta) per verificare se un numero è primo.
 * 
 * Un numero primo è un numero intero maggiore di 1 che ha esattamente due divisori: 
 * 1 e se stesso. Questa funzione testa tutti i possibili divisori 'i' partendo da 2 
 * fino ad arrivare a n - 1 (o meglio, fino a radice quadrata di n).
 * 
 */
bool is_prime_naive(long long n) {
    // CASO BASE: I numeri minori o uguali a 1 non sono primi per definizione
    if (n <= 1) {
        return false;
    }

    // Testiamo tutti i possibili divisori da 2 fino a n - 1.
    // NOTA: 
    // Possiamo fermarci molto prima di n - 1? 
    // Sì! Basta fermarsi a radice quadrata di n (i * i <= n).
    // Se lasciamo 'i < n', per un numero di 10 cifre, la macchina farebbe un miliardo 
    // di iterazioni (troppo lento!). Con 'i * i <= n' riduciamo drasticamente i tempi.
    for (long long i = 2; i * i <= n; i++) { // provate come condizione di fine ciclo ' i < n ' e vedete che succede con vari input
        // Se 'n' è divisibile per 'i' (resto della divisione zero), 
        // significa che ha trovato un divisore oltre 1 e se stesso -> NON è primo.
        if (n % i == 0) {
            return false;
        }
    }

    // Se il ciclo finisce senza aver trovato alcun divisore, il numero è primo.
    return true;
}


int main(void) {
    long long a, b;

    printf("Inserisci il primo estremo (a): ");
    if (scanf("%lld", &a) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    printf("Inserisci il secondo estremo (b): ");
    if (scanf("%lld", &b) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    /** Cosa succede se l'utente inserisce prima il numero più grande (es. a = 50, b = 10)?
     * Un programma poco robusto fallirebbe o non stamperebbe nulla. 
     * Gestire lo scambio (swap) con una variabile temporanea rende il programma 
     * più robusto a input poco attenti.
     * Bisogna sempre gestire il fatto che l'utente potrebbe inserire gli input in maniera inattesa.
     */
    if (a > b) {
        long long temp = a;
        a = b;
        b = temp;
    }

    printf("Numeri primi compresi tra %lld e %lld:\n", a, b);
    int trovati = 0;

    // Scorre tutti i numeri dall'estremo inferiore a quello superiore
    for (long long i = a; i <= b; i++) {
        if (is_prime(i)) {
            printf("%lld ", i);
            trovati++;
        }
    }

    if (trovati == 0) {
        printf("Nessun numero primo trovato in questo intervallo.");
    }
    printf("\n");

    return 0;
}
