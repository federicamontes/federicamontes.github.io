#include <stdio.h>

/**
1. Scrivi un programma C che prenda in input un intero n, e calcoli e stampi l'n-esimo termine della sequenza di Fibonacci. Usa un algoritmo iterativo. 
Scrivi anche pseudocodice, e mostra dei casi di test per il codice (esempi di input e relativo output).
*/


/**
Come testare un programma:
normalmente per testare che un programma sia corretto, non dobbiamo inserire solo valori in input che sappiamo essere corretti
ma bisogna testare anche dei valori che siano "limite", i casi limite sono diversi per ogni tipo di problema, ovviamente.
IN questo caso, valori di input da testare sono:
- i casi base (per testare se nel codice siano stati correttamente previsti i casi base)
- valori piccoli (es. 4, 5) che siano facilmente validabili a mano eseguendo il calcolo della formula
- valori intermedi (es. 10), che siano ancora validabili a mano con più iterazioni dell'algoritmo
- input non validi (es. numeri negativi), per verificare che sia stato gestito il caso di input scorretto con messaggi di errore
- valore incalcolabile (es. 93), per testare l'overflow
*/


/**
 * Funzione che calcola l'N-esimo termine di Fibonacci in modo iterativo.
 * 
 * NOTA:
 * 1. Perché usare 'unsigned long long'? 
 *    La sequenza di Fibonacci cresce in modo esponenziale. Un normale 'int' 
 *    andrebbe in overflow a un certo punto. 'unsigned long long' estende 
 *    il limite, permettendoci di calcolare termini più alti.
 * 2. Scelta dell'algoritmo: 
 *    L'approccio iterativo con un ciclo for ha una complessità temporale O(N) 
 *    e spaziale O(1), evitando i problemi di stack overflow tipici di una 
 *    soluzione ricorsiva non ottimizzata.
 */
unsigned long long fibonacci(int n) {
    // casi base della sequenza F(0) = 1 e F(1) = 1 
    if (n == 0) return 0;
    if (n == 1) return 1;

    unsigned long long precedente = 0; //F(i-2)
    unsigned long long corrente = 1; // F(i-1)
    unsigned long long successivo = 0; // F(i)

    // iteriamo dal terzo termine in poi
    for (int i = 2; i <= n; i++) {
        successivo = precedente + corrente;
        precedente = corrente; // facciamo scorrere i valori
        corrente = successivo;
    }

    return corrente;
}

int main(void) {
    int n;

    printf("Inserisci la posizione N della serie di Fibonacci: ");
    /* 
     * CONTROLLO DI ROBUSTEZZA (Fondamentale all'esame e nella vita in generale):
     * Verifichiamo sia che scanf abbia letto correttamente un intero (!= 1), 
     * sia che il numero non sia negativo (le posizioni di Fibonacci non sono negative).
     */
    if (scanf("%d", &n) != 1 || n < 0) {
        printf("Errore: inserisci un numero intero maggiore o uguale a 0.\n");
        return 1;
    }

    unsigned long long risultato = fibonacci(n);
    printf("Il %d-esimo termine della serie di Fibonacci e': %llu\n", n, risultato);

    return 0;
}
