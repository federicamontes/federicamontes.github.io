#include <stdio.h>
#include <stdbool.h>

/* 6. Scrivi un programma C che dato un numero intero positivo N, non necessariamente primo, calcoli il successivo numero primo, stampandolo.

L'obiettivo di questo esercizio non è tanto scrivere la soluzione più efficiente (che non si può conoscere se non è stato studiato
l'algoritmo specifico.. Piuttosto è capire bene la differenza tra for e while, eventualmente poi è richiesto lo scatto mentale
di rendersi conto che la condizione di fine for i < n è enormemente inefficiente.
*/

/**
 * Funzione per verificare se un numero è primo (riutilizzata dall'esercizio precedente).
 * 
 * NOTA:
 * Scrivere una funzione helper come `is_prime` ci permette di isolare la logica 
 * complessa e riutilizzarla ovunque serva, senza doverla riscrivere da capo.
 */
bool is_prime(long long n) {
    if (n <= 1) return false;
    if (n <= 3) return true;
    if (n % 2 == 0 || n % 3 == 0) return false;
    
    for (long long i = 5; i * i <= n; i += 6) {
        if (n % i == 0 || n % (i + 2) == 0)
            return false;
    }
    return true;
}

/**
 * Funzione "Naive" (Forza Bruta) per verificare se un numero è primo.
 * 
 * COME FUNZIONA:
 * Testa tutti i possibili divisori 'i' partendo da 2 fino alla radice quadrata di n (i * i <= n).
 * Se trova un divisore che dà resto zero, il numero non è primo.
 */
bool is_prime_naive(long long n) {
    if (n <= 1) {
        return false; // I numeri minori o uguali a 1 non sono primi
    }

    // Proviamo a dividere 'n' per tutti i numeri da 2 fino a radice quadrata di n
    for (long long i = 2; i * i <= n; i++) {
        if (n % i == 0) {
            return false; // Trovato un divisore: non è primo!
        }
    }

    return true; // Nessun divisore trovato: il numero è primo
}

int main(void) {
    long long n;

    printf("Inserisci un numero intero: ");
    if (scanf("%lld", &n) != 1) {
        printf("Input non valido.\n");
        return 1;
    }

    // Partiamo a controllare dal numero successivo (n + 1)
    // che succede se partiamo da n invece che n+1?
    long long prossimo = n + 1;

    // Continuamo a incrementare finché non troviamo un numero primo
    while (!is_prime(prossimo)) {
        prossimo++;
    }

    printf("Il primo numero primo successivo a %lld e': %lld\n", n, prossimo);

    return 0;
}
