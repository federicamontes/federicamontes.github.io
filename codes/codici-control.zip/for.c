#include <stdio.h>

int main(void)
{
  int n;
  double x, y;

  printf("Dammi due numeri\n");
  scanf("%d %lf",&n,&x);
  printf("Value: %d %lf \n",n,x);
  y=1.0;

  int i; // ricordate che posso dichiarare la variabile di ciclo anche dentro il for, ma in quel caso come cambia lo scope della variabile?
  for (i = 1; i <= n; i++) {
    y = y*x;
  }
  printf("Result: %lf\n",y);

    
  return(0);
}
