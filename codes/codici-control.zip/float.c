#include <stdio.h>
#include <math.h> // per fabs()
#include <float.h> // per i limits

int main(void) {
    double a = 0.1 + 0.2;
    double b = 0.3;

    printf("a = %lf\n", a);
    printf("b = %lf\n", b);

    
    if (a == b) {
        printf("a e b sono UGUALI\n");
    } else {
        printf("a e b NON sono uguali\n");
    }

    if (fabs(a-b) < FLT_EPSILON) { 
	printf("a e b sono uguali a meno di una costante!\n");
    }

    return 0;
}
