#include <stdio.h>

int globale = 100; // File Scope

void funzione_A() {
    printf("%d\n", globale); 
}

int main() {
    funzione_A();
    printf("%d\n", globale); 
    return 0;
}
