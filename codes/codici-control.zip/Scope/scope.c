#include <stdio.h>

int x = 10; // Global scope

int main() {
    int x = 20; // Shadowing della globale
    
    if (x!=0){
        int x = 30; // Shadowing locale
        printf("%d\n", x); 
    }
    
    printf("%d\n", x); 
    return 0;
}
