#include <stdio.h>

int main(void) {
    int x = 10; // Visibile in tutta la funzione
    
    if (x > 5) {
        int y = 20; // Block scope di 'if'
        printf("%d %d\n", x, y); 
    }
    
    printf("%d", y); // cosa succede? 

   return 0;
}
