#include <stdio.h>

void contaChiamate() {
    // Variabile locale normale (automatica): rinasce e muore a ogni chiamata
    int contatoreNormale = 0;
    
    // Variabile statica locale: viene inizializzata UNA SOLA VOLTA 
    // e conserva il suo valore tra le chiamate successive!
    static int contatoreStatico = 0;

    contatoreNormale++;
    contatoreStatico++;

    printf("Normale: %d | Statico: %d\n", contatoreNormale, contatoreStatico);
}

int main(void) {
    printf("Prima chiamata alla funzione:\n");
    contaChiamate();

    printf("\nSeconda chiamata alla funzione:\n");
    contaChiamate();

    printf("\nTerza chiamata alla funzione:\n");
    contaChiamate();

    return 0;
}
