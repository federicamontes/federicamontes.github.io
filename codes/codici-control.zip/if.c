#include <stdio.h>

int main(void)
{
  int i = 0, j, k;

  j = 25;

  if (i != 0) { // ricordate come vengono valutati i bool in C: potrei scrivere anche if(i)
    k = j/i;
  } else {
    fprintf(stderr, "Non dividere per zero!\n");
  }
  
  return 0;
}
