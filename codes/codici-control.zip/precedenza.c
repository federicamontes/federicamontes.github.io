#include <stdio.h>

int main(void) {
    int a = 5, b = 3;

    // Calcolo del massimo con effetto collaterale:
    // Se a > b, la branca scelta viene eseguita E incrementata.
    int max = (a > b) ? a++ : b++;

    // COSA SUCCEDE QUI?
    // 1. (a > b) -> (5 > 3) è VERO.
    // 2. Viene valutato a++: restituisce il valore ATTUALE di a (5), poi incrementa a a 6.
    // 3. 'max' riceve 5. 'a' diventa 6.
    printf("max = %d, a = %d, b = %d\n", max, a, b);

    // Attenzione alla precedenza con l'operatore di assegnamento!
    int x = 10;
    int y = 20;
    
    // Gli operatori aritmetici hanno precedenza rispetto al ternario
    int ris = x + y > 25 ? 100 : 200; // Valutato come: ((x + y) > 25) ? 100 : 200
    printf("Risultato: %d\n", ris);

    return 0;
}
