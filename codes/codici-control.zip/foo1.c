#include <stdio.h>


// passaggio per valore, cosa succede quando torniamo nel main?
void foo(int a)
{
  a = a + 1;
  printf("Dentro foo=%d\n",a);
}

int main(void)
{
  int n = 10;

  printf("Dentro main, prima di foo()=%d\n",n);
  foo(n);
  printf("Dentro main, dopo foo()=%d\n",n);
  return 0;
}
  
