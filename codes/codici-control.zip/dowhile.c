#include <stdio.h>

int main(void) {
    int numero;

    // Chiedi il numero almeno una volta; ripeti se l'utente inserisce un valore non valido
    do {
        printf("Inserisci un numero positivo (maggiore di 0): ");
        scanf("%d", &numero);


    } while (numero <= 0); // Notare il punto e virgola obbligatorio alla fine!

    printf("\nPerfetto! Hai inserito il numero: %d\n", numero);

    return 0;
}
