#include <stdio.h>

int main() {
    int scelta;

    printf("=== DISTRIBUTORE AUTOMATICO ===\n");
    printf("1. Acqua\n");
    printf("2. Caffe'\n");
    printf("3. Cioccolata\n");
    printf("Fai la tua scelta (1-3): ");
 
    // chiedo allo stdin (standard input) un valore INTERO (%d) 
    scanf("%d", &scelta); // per capire cosa fa la scanf usare il man su terminale!

    switch (scelta) { // è equivalente a scrivere un blocco if-else if-else if-else... ma più compatto
        case 1:
            printf("Hai scelto: Acqua. Prezzo: 0.50 euro.\n");
            break; // Fondamentale: esce dallo switch, che succede se non lo metto?
            
        case 2:
            printf("Hai scelto: Caffè. Prezzo: 1.00 euro.\n");
            break;
            
        case 3:
            printf("Hai scelto: Cioccolata. Prezzo: 1.50 euro.\n");
            break;
            
        default: // tutti gli altri casi non elencati (otherwise)
            printf("Errore: Scelta non valida!\n");
            break;
    }

    return 0;
}
