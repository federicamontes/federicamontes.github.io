#include <stdio.h>

int main(void) {
    int a = 0;
    int b = 10;

    
    if (a != 0 && (b / a) > 2) {
        printf("Condizione vera\n");
    } else {
        printf("Condizione falsa\n");
    }

    
    int x = 0;
    if (a!=0 && ++x) { //short-circuit evaluation
        printf("TRUE valore di x: %d\n", x);
    }
    printf("Valore di x: %d\n", x);

    return 0;
}
