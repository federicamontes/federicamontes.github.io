#include <stdio.h>

int main(void)
{
  unsigned int i;

  printf("Dammi un numero\n");
  scanf("%u",&i);

  printf("Value: %u\n",i);
 
   while ( i > 1 ) {
    if (i % 2 == 0) {
      i /= 2;
    } else {
      i = 3*i+1;
    }
    printf("Value: %u\n",i);
  }
    
  return 0;
}
