#include <stdio.h>

int main(void) {
    // Array allocato sullo Stack: MODIFICABILE
    char s_stack[] = "Ciao";
    s_stack[0] = 'c'; 
    printf("Stringa su Stack: %s\n", s_stack);

    // Puntatore a String Literal (memorizzato in .rodata): NON MODIFICABILE
    char *s_literal = "Ciao";
    printf("Stringa Literal: %s\n", s_literal);

    
    s_literal[0] = 'c'; 

    return 0;
}
