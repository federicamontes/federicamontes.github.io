#include <stdio.h>

int main(void) {
    int x = 10, y = 20;

    // Puntatore a valore intero costante (non puoi modificare il valore puntato)
    const int *p1 = &x;
//    *p1 = 15;
    p1 = &y;

   // Puntatore costante a valore intero
   int * const p2 = &x;
   *p2 = 15;
//    p2 = &y;

   // Puntatore costante a valore intero costante
   const int * const p3 = &x;
   *p3 = 10;
   p3 = &y;



    return 0;
}
