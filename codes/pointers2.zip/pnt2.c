#include <stdio.h>
#include <stdlib.h>

/*
Cosa succede quando dal main chiamo questa funzione passando un int * ?
Memory leak + passaggio per valore
Come si risolve questo?
*/
void init(int n, int *v) {
    v = (int *)malloc(n * sizeof(int));
    printf("  [init] Allocato in locale (v_copia): %p\n", (void *)v);

}

int main(void) {
    int *v = NULL;
    int n = 8;

    
    printf("Prima di init, v = %p\n", v);
    init(n, v);
    printf("Dopo init,   v = %p  \n\n", v);

    return 0;
}
