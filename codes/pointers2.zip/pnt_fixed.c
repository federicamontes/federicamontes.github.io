#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <float.h>

#define N  10

void init(int n,  int **v)
{
  int i;
  *v=(int *) malloc(n*sizeof(int));

  if (*v == NULL) {
    printf("malloc ha fallito!!!\n");
  } else  {
    
    for (i=0; i<n; i++) {
      (*v)[i] = i ;
      printf("%d   %d \n",i, (*v)[i]);
    }
  }
}



int main(void)
{
  int *a=NULL, b, c, n,i, *v=NULL;
  
  n = 8;

  
  init(n,&v);
  fprintf(stderr,"Done init\n");
  for (i=0; i<n; i++)
    printf("%d   %d \n",i, v[i]);
  

  
  return(0);
    
}
