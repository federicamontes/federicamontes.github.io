#include <stdio.h>

int main(void) {

	int *p = NULL; // buona pratica inizializzare i puntatori a NULL (ovviamente non accedetevi prima di inizializzarli..)
	int a = 0;
	
	if (a == 0) {
		int x = 10;
		p = &x; // p punta all'indirizzo di x, locale al blocco!
	} // <-- FINE DEL BLOCCO: x muore
//	printf("Il valore di x %d \t l'indirizzo di x %p: \n", x, &x);
	// ORA 'p' È UN DANGLING POINTER!
	// Punta a un'area di memoria non più valida per x
	printf("Stampa l'indirizzo %p\n", p);
	printf("Stampa il valore %d\n", *p); // Comportamento imprevedibile


	return 0;

}


//Compilare questo codice con -Wall -Wextra, e poi anche con -O2
