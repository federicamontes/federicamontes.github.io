#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <stdint.h>
#include <float.h>

#define N  10

void init(int n,  int **v)
{
  int i;
  *v = (int *) malloc(n*sizeof(int));

  // controllo di errore su indirizzo di ritorno!
  if (*v == NULL) {
    printf("malloc ha fallito!!!\n");
  } else  {
    // inizializzo l'array allocato
    for (i=0; i<n; i++) {
      // cosa succede quando eseguo questa istruzione?
      *v[i] = i ;  // equivalente a *(*(v+i))
      printf("Stampo il valore: %d   %d \n",i, *v[i]);
    }
  }
}



int main(void)
{
  int *a=NULL, b, c, n,i, *v=NULL;
  
  n = 8;

  // passaggio per indirizzo di v
  init(n,&v);
  fprintf(stderr,"Done init\n");
  for (i=0; i<n; i++)
    printf("%d   %d \n",i, v[i]);
  

  
  return(0);
    
}
