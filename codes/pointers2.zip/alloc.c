#include <stdio.h>
#include <stdlib.h> // Necessario per malloc, calloc, realloc e free

int main(void) {
    int n;

    printf("Inserisci un numero intero positivo: \n");
    scanf("%d", &n);

    if (n <= 0) {
	fprintf(stderr, "Impossibile allocare una dimensione <= 0!");
	return 1; //ritorniamo un numero != 0 per segnalare errore
    }
    // ==========================================
    // 1. MALLOC (Memory Allocation)
    // ==========================================
    // Alloca spazio per 'n' interi. La memoria NON viene inizializzata (contiene valori casuali).
    int *arr_malloc = (int *)malloc(n * sizeof(int));
    
    if (arr_malloc == NULL) {
        printf("Errore di allocazione con malloc!\n");
        return 1;
    }

    // Assegniamo manualmente dei valori
    //arr_malloc[0] = 10;
    //arr_malloc[1] = 20;
    //arr_malloc[2] = 30;

    printf("Valori dopo malloc (non inizializzati, poi sovrascritti):\n");
    for (int i = 0; i < n; i++) {
        printf("arr_malloc[%d] = %d\n", i, arr_malloc[i]); // se sono 0, è puramente casuale!
    }

    // Assegniamo manualmente dei valori
    arr_malloc[0] = 10;
    arr_malloc[1] = 20;
    arr_malloc[2] = 30;


    // ==========================================
    // 2. CALLOC (Contiguous Allocation)
    // ==========================================
    // Alloca spazio per 'n' interi E INIZIALIZZA AUTOMATICAMENTE TUTTI I BIT A ZERO (0).
    int *arr_calloc = (int *)calloc(n, sizeof(int)); // passo anche come parametri il numero di elementi "n"
    
    if (arr_calloc == NULL) {
        printf("Errore di allocazione con calloc!\n");
        free(arr_malloc);
        return 1;
    }

    printf("\nValori dopo calloc (inizializzati automaticamente a 0):\n");
    for (int i = 0; i < n; i++) {
        printf("arr_calloc[%d] = %d\n", i, arr_calloc[i]);
    }


    // ==========================================
    // 3. REALLOC (Reallocation)
    // ==========================================
    // Vogliamo ingrandire il primo array (arr_malloc) da 3 a 5 elementi.
    int nuova_dimensione;
    printf("Inserisci un altro intero positivo: \n");
    scanf("%d", &nuova_dimensione);
    if (nuova_dimensione <= 0) {
        fprintf(stderr, "Impossibile allocare una dimensione <= 0!");
        return 1; //ritorniamo un numero != 0 per segnalare errore
    }

    nuova_dimensione += n; //aumento la nuova dimensione presa da input alla dimensione n precedente
    int *arr_temp = (int *)realloc(arr_malloc, (nuova_dimensione) * sizeof(int));

    if (arr_temp == NULL) {
        printf("Errore durante il ridimensionamento con realloc!\n");
        free(arr_malloc);
        free(arr_calloc);
        return 1;
    }
    
    // Aggiorniamo il puntatore principale
    arr_malloc = arr_temp;

    // Inseriamo i valori nei nuovi spazi creati (indici 3 e 4)
    arr_malloc[3] = 40;
    arr_malloc[4] = 50;

    printf("\nValori dopo realloc (array ingrandito a 5 elementi):\n");
    for (int i = 0; i < nuova_dimensione; i++) {
        printf("arr_malloc[%d] = %d\n", i, arr_malloc[i]);
    }


    // ==========================================
    // 4. FREE (Rilascio della memoria)
    // ==========================================
    // È fondamentale liberare sempre la memoria allocata per evitare memory leak. Normalmente alla fine del main() tutta la memoria viene liberata.. 
    // ma è buona pratica fare free esplicitamente.
    free(arr_malloc);
//    free(arr_temp); // che succede se scommento questa riga? perché?
    free(arr_calloc);

    printf("\nMemoria liberata correttamente.\n");
    return 0;
}
