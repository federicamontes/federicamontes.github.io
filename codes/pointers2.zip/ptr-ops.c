#include <stdio.h>

int main(void) {
    int a = 10;
    int b = 20;
    
    int *p1 = &a;
    int *p2 = &b;

    *p1 = *p1 + 5;     // Quanto vale 'a'?
    *p2 = *p1;         // Quanto vale 'b'?

    printf("BEFORE PTR EXCHANGE a = %d, b = %d\n", a, b);
    
    p1 = p2;           // ORA dove punta 'p1'?
    *p1 = 50;          // Quale variabile cambia, 'a' o 'b'?

    printf("a = %d, b = %d\n", a, b);
    printf("*p1 = %d, *p2 = %d\n", *p1, *p2);

    return 0;
}
