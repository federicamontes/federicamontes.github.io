#include <stdio.h>

// Calcola la somma usando due puntatori: inizio e fine
int somma_range(const int *begin, const int *end) {
    int somma = 0;
    // Il ciclo prosegue finche' il puntatore di scorrimento non raggiunge la fine
    for (const int *ptr = begin; ptr < end; ptr++) {
        somma += *ptr;
    }
    return somma;
}

int main(void) {
    int v[] = {3, 5, 2, 8, 4};
    int n = sizeof(v) / sizeof(v[0]);

    // v e' l'inizio (&v[0]), (v + n) e' l'indirizzo dell'elemento "successivo all'ultimo"
    int totale = somma_range(v, v + n); // implicitamente stiamo passando informazioni sulla dimensione dell'array..
    printf("Somma totale: %d\n", totale);

    // Possiamo passare anche sub-array senza duplicare memoria!
    // Somma dal 2° al 4° elemento (indici 1, 2, 3)
    int sotto_somma = somma_range(v + 1, v + 4);
    printf("Somma sotto-array v[1..3]: %d\n", sotto_somma);

    return 0;
}
