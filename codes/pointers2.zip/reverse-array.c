#include <stdio.h>

void reverse_in_place(int *left, int *right) {
    // right punta all'ultimo elemento valido (non indirizzo successivo all'ultimo)
    while (left < right) {
        // Scambio dei valori tramite dereferenziazione
        int temp = *left;
        *left = *right;
        *right = temp;

        // Avanzamento dei due puntatori verso il centro
        left++;
        right--;
    }
}

int main(void) {
    int v[] = {1, 2, 3, 4, 5};
    int n = 5;

    reverse_in_place(v, v + n - 1);

    printf("Array invertito: ");
    for (int i = 0; i < n; i++) printf("%d ", v[i]);
    printf("\n");

    return 0;
}
