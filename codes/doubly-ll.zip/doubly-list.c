#include "doubly-list.h"

// Creazione di un nuovo nodo
Node* createNode(int data) {
    Node* newNode = (Node*)malloc(sizeof(Node));
    if (!newNode) {
        printf("Errore di allocazione memoria.\n");
        exit(EXIT_FAILURE);
    }
    newNode->data = data;
    newNode->prev = NULL; // init anche del prev
    newNode->next = NULL;
    return newNode;
}

// Stampa in avanti (dalla testa alla coda)
void printListForward(Node* head) {
    Node* temp = head;
    printf("Forward:  NULL <-> ");
    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->next;
    }
    printf("NULL\n");
}

// Stampa all'indietro (dalla coda alla testa) - Dimostra la potenza del puntatore prev!
void printListBackward(Node* tail) {
    Node* temp = tail;
    printf("Backward: NULL <-> ");
    while (temp != NULL) {
        printf("%d <-> ", temp->data);
        temp = temp->prev;
    }
    printf("NULL\n");
}

// Liberazione della memoria
void freeList(Node** head) {
    Node* temp;
    while (*head != NULL) {
        temp = *head;
        *head = (*head)->next;
        free(temp);
    }
}

// ==========================================
// OPERAZIONI CORE CON DOPPIO PUNTATORE
// ==========================================

/**
 * Inserimento generico doppiamente concatenato:
 * - 'prec' è l'indirizzo del puntatore da aggiornare (&head o &prev_node->next).
 * - 'prev_node' è il nodo precedente (NULL se inseriamo in testa).
 * Perché prec è un Node ** mentre prev_node è un Node *? Perché non c'è bisogno di
 * modificare l'INDIRIZZO di prev_node, ma è sufficiente sapere CHI È per collegare il nuovo nodo 
 * Invece prec è il punto di aggancio vero e proprio, l'indirizzo del puntatore che voglio modificare
 * per inserire newNode. Quindi prec deve smettere di puntare dove puntava prima e iniziare a puntare
 * a newNode, per modificare il puntatore devo passare l'indirizzo.
 */
void insertD(Node **prec, Node *prev_node, Node *newNode) {
    if (newNode == NULL || prec == NULL) return;

    // Collega il nuovo nodo al successivo
    newNode->next = *prec;
    // Collega il nuovo nodo al precedente
    newNode->prev = prev_node;

    // Aggiorna il puntatore originale (head o prev->next)
    *prec = newNode; 

    // Se esiste un nodo successivo, aggiorna il suo puntatore 'prev'
    if (newNode->next != NULL) {
        newNode->next->prev = newNode;
    }
}

/**
 * Rimozione generica che scollega e restituisce il nodo:
 * Gestisce automaticamente la correzione dei link 'next' e 'prev'.
 */
Node* deleteD(Node **prec) {
    if (prec == NULL || *prec == NULL) {
        return NULL;
    }

    Node *target = *prec;     // Il nodo da rimuovere

    // Salta il nodo bersaglio nel collegamento in avanti
    *prec = target->next;

    // Se esiste un nodo successivo, aggiorna il suo puntatore 'prev' all'indietro
    if (target->next != NULL) {
        target->next->prev = target->prev;
    }

    // Isola completamente il nodo estratto
    target->next = NULL;
    target->prev = NULL;

    return target;
}

// ==========================================
// FUNZIONI DI ALTO LIVELLO (Ordinamento)
// ==========================================

// Inserimento ordinato sfruttando insertD
void insertOrderedD(Node **head, int data) {
    Node *newNode = createNode(data);
    Node **prec = head;
    Node *prev_node = NULL;

    // Scorriamo finché non troviamo la posizione corretta
    while (*prec != NULL && (*prec)->data < newNode->data) {
        prev_node = *prec;
        prec = &((*prec)->next);
    }

    // Inseriamo usando la funzione generica
    insertD(prec, prev_node, newNode);
}

// Eliminazione di un valore specifico sfruttando deleteD
void deleteValueD(Node** head, int key) {
    if (head == NULL || *head == NULL) return;

    Node **prec = head;

    // Cerca il puntatore che punta al nodo con la chiave
    while (*prec != NULL && (*prec)->data != key) {
        prec = &((*prec)->next);
    }

    // Se trovato, lo rimuoviamo e deallochiamo la memoria
    if (*prec != NULL) {
        Node *removed = deleteD(prec);
        if (removed != NULL) {
            free(removed);
        }
    }
}
