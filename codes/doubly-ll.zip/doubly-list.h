#ifndef DOUBLY_LIST_H
#define DOUBLY_LIST_H

#include <stdio.h>
#include <stdlib.h>

// Definizione del nodo della lista doppia
typedef struct Node {
    int data;
    struct Node* prev;
    struct Node* next;
} Node;

// Prototipi delle funzioni di utilità
Node* createNode(int data);
void printListForward(Node* head);
void printListBackward(Node* tail);
void freeList(Node** head);

// Funzioni core con puntatore a puntatore (Node **) e gestione simmetrica dei link
void insertD(Node **prec, Node *prev_node, Node *newNode);
Node* deleteD(Node **prec);

// Funzioni derivate di alto livello
void insertOrderedD(Node **head, int data);
void deleteValueD(Node** head, int key);

#endif // DOUBLY_LIST_H
